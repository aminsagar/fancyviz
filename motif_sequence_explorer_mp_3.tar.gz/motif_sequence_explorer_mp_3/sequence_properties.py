from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Tuple

import math
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor, as_completed
import os

from amino_acid_scales import load_scales


def feature_key(category: str, subcategory: str) -> str:
    """Canonical column name for a category/subcategory pair."""
    return f"{category}::{subcategory}"


ALPHABET = "ACDEFGHIKLMNPQRSTVWY"
AA_TO_INDEX = {aa: idx for idx, aa in enumerate(ALPHABET)}
UNKNOWN_INDEX = len(ALPHABET)

_WORKER_SCALE_ARRAYS: Dict[str, np.ndarray] | None = None
_WORKER_SUBCATEGORY_SCALES: Dict[Tuple[str, str], List[str]] | None = None


def _init_worker(scale_arrays: Dict[str, np.ndarray], subcategory_scales: Dict[Tuple[str, str], List[str]]):
    global _WORKER_SCALE_ARRAYS, _WORKER_SUBCATEGORY_SCALES
    _WORKER_SCALE_ARRAYS = {k: v for k, v in scale_arrays.items()}
    _WORKER_SUBCATEGORY_SCALES = subcategory_scales


def _decode_codes(byte_data: bytes, length: int) -> np.ndarray:
    return np.frombuffer(byte_data, dtype=np.uint8, count=length)


def _compute_row(args: Tuple[int, bytes, int]) -> Dict[str, float]:
    seq_idx, byte_data, length = args
    codes = _decode_codes(byte_data, length)
    row: Dict[str, float] = {"sequence_index": seq_idx}
    for (category, subcategory), scale_ids in _WORKER_SUBCATEGORY_SCALES.items():
        values = []
        for scale_id in scale_ids:
            arr = _WORKER_SCALE_ARRAYS[scale_id]
            seq_values = arr[codes]
            mean_val = np.nanmean(seq_values)
            if not math.isnan(mean_val):
                values.append(mean_val)
        if values:
            row[feature_key(category, subcategory)] = float(np.mean(values))
    return row


@dataclass
class ScaleCatalog:
    """Category/subcategory metadata for AAindex scales."""

    df_cat: pd.DataFrame = field(default_factory=lambda: load_scales("scales_cat"))

    def __post_init__(self):
        self._map: Dict[str, Dict[str, List[str]]] = {}
        for _, row in self.df_cat.iterrows():
            cat = row["category"]
            sub = row["subcategory"]
            scale_id = row["scale_id"]
            self._map.setdefault(cat, {}).setdefault(sub, []).append(scale_id)

    def categories(self) -> List[str]:
        return sorted(self._map.keys())

    def subcategories(self, category: str | None) -> List[str]:
        if category is None:
            return []
        return sorted(self._map.get(category, {}).keys())

    def scale_ids(self, category: str, subcategory: str) -> List[str]:
        return list(self._map.get(category, {}).get(subcategory, []))

    def pairs(self) -> List[Tuple[str, str]]:
        combinations: List[Tuple[str, str]] = []
        for category in self.categories():
            for sub in self.subcategories(category):
                combinations.append((category, sub))
        return combinations


@dataclass
class SequencePropertyCalculator:
    """Compute and cache sequence-level AAindex summaries."""

    df_scales: pd.DataFrame = field(default_factory=load_scales)
    catalog: ScaleCatalog = field(default_factory=ScaleCatalog)
    max_workers: int | None = None

    def __post_init__(self):
        self.scale_arrays = self._build_scale_arrays()
        self.subcategory_scales = {
            pair: self.catalog.scale_ids(*pair)
            for pair in self.catalog.pairs()
            if self.catalog.scale_ids(*pair)
        }

    def _build_scale_arrays(self) -> Dict[str, np.ndarray]:
        arrays: Dict[str, np.ndarray] = {}
        for scale_id in self.df_scales.columns:
            series = self.df_scales[scale_id]
            arr = np.full(UNKNOWN_INDEX + 1, np.nan, dtype=np.float32)
            for aa, value in series.items():
                aa = str(aa).upper()
                if aa in AA_TO_INDEX:
                    arr[AA_TO_INDEX[aa]] = float(value)
            arrays[scale_id] = arr
        return arrays

    def _encode_sequence(self, sequence: str) -> np.ndarray:
        return np.fromiter((AA_TO_INDEX.get(ch.upper(), UNKNOWN_INDEX) for ch in sequence), dtype=np.uint8)

    def compute_features(self, sequence_lookup: Mapping[int, str]) -> pd.DataFrame:
        """Return dataframe of per-sequence category/subcategory averages."""
        items = [(idx, seq) for idx, seq in sequence_lookup.items() if isinstance(seq, str) and seq]
        if not items:
            return pd.DataFrame(columns=["sequence_index"])

        encoded = [(idx, self._encode_sequence(seq)) for idx, seq in items]
        tasks = [(idx, codes.tobytes(), len(codes)) for idx, codes in encoded]

        num_workers = self.max_workers or os.cpu_count() or 1
        num_workers = max(1, min(num_workers, len(tasks)))

        global _WORKER_SCALE_ARRAYS, _WORKER_SUBCATEGORY_SCALES

        if num_workers == 1:
            _WORKER_SCALE_ARRAYS = self.scale_arrays
            _WORKER_SUBCATEGORY_SCALES = self.subcategory_scales
            rows = [_compute_row(task) for task in tasks]
        else:
            rows = []
            try:
                with ProcessPoolExecutor(
                    max_workers=num_workers,
                    initializer=_init_worker,
                    initargs=(self.scale_arrays, self.subcategory_scales),
                ) as executor:
                    futures = [executor.submit(_compute_row, task) for task in tasks]
                    for future in futures:
                        rows.append(future.result())
            except (PermissionError, OSError):
                _WORKER_SCALE_ARRAYS = self.scale_arrays
                _WORKER_SUBCATEGORY_SCALES = self.subcategory_scales
                rows = [_compute_row(task) for task in tasks]

        return pd.DataFrame(rows)
