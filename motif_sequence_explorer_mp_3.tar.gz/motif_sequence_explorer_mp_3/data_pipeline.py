from __future__ import annotations

import itertools
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, MutableMapping, Set, Tuple

import pandas as pd
import numpy as np
import time
from datetime import datetime

from .sequence_properties import SequencePropertyCalculator

TOKEN_PATTERN = re.compile(r"\[[0-9]+\]|[A-Z]")


def tokenize_motif(motif: str) -> List[str]:
    """Split motif strings into comparable tokens."""
    if not isinstance(motif, str):
        return []
    motif = motif.strip().upper()
    return TOKEN_PATTERN.findall(motif)


def normalized_motif(motif: str) -> str:
    """Return a compact token string for substring comparisons."""
    return "".join(tokenize_motif(motif))


def is_parent_of(parent: str, child: str) -> bool:
    """Heuristic parent/child relationship based on token containment."""
    if not parent or not child or parent == child:
        return False
    parent_norm = normalized_motif(parent)
    child_norm = normalized_motif(child)
    if not parent_norm or not child_norm:
        return False
    if len(parent_norm) >= len(child_norm):
        return False
    return parent_norm in child_norm


@dataclass
class MotifDataset:
    """Container for the processed dataset used by the Dash app."""

    sequences: pd.DataFrame
    exploded: pd.DataFrame
    motif_table: pd.DataFrame
    consolidated_table: pd.DataFrame
    hierarchy: Dict[str, List[str]]
    parent_map: Dict[str, str]
    motif_to_sequences: Dict[str, Set[int]]
    sequence_lookup: Dict[int, str]
    sequence_to_motifs: Dict[int, Set[str]]
    co_occurrence: pd.DataFrame
    co_occurrence_matrix: pd.DataFrame
    sequence_features: pd.DataFrame


class ProgressLogger:
    """Collect human-readable log lines for long-running tasks."""

    def __init__(self):
        self.entries: List[str] = []

    def log(self, message: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.entries.append(f"[{timestamp}] {message}")

    def extend(self, message: str):
        self.log(message)


def load_sequence_file(path: Path | str, limit: int | None = None) -> pd.DataFrame:
    """Load the raw sequence→motif CSV in its new format."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Sequence file not found: {path}")
    df = pd.read_csv(path)
    required = {"sequence_index", "sequence", "motifs"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Sequence file missing required columns: {missing}")
    if limit is not None:
        df = df.head(limit)
    df["motifs_list"] = (
        df["motifs"]
        .fillna("")
        .astype(str)
        .apply(lambda value: [motif.strip() for motif in value.split(";") if motif.strip()])
    )
    df = df[df["motifs_list"].map(bool)].reset_index(drop=True)
    return df


def explode_motifs(df: pd.DataFrame) -> pd.DataFrame:
    """Explode the motif lists so every row references a single motif."""
    exploded = df.explode("motifs_list").rename(columns={"motifs_list": "motif"})
    exploded = exploded.dropna(subset=["motif"])
    exploded["motif"] = exploded["motif"].str.strip()
    return exploded.reset_index(drop=True)


def build_sequence_maps(exploded: pd.DataFrame) -> Tuple[Dict[str, Set[int]], Dict[int, str], Dict[int, Set[str]]]:
    """Return motif→sequences, sequence→sequence string, and sequence→motifs mappings."""
    motif_to_sequences: Dict[str, Set[int]] = {}
    sequence_lookup: Dict[int, str] = {}
    sequence_to_motifs: Dict[int, Set[str]] = {}

    for _, row in exploded.iterrows():
        motif = row["motif"]
        seq_idx = int(row["sequence_index"])
        sequence_lookup[seq_idx] = row["sequence"]
        motif_to_sequences.setdefault(motif, set()).add(seq_idx)
        sequence_to_motifs.setdefault(seq_idx, set()).add(motif)

    return motif_to_sequences, sequence_lookup, sequence_to_motifs


def build_assignments(exploded: pd.DataFrame) -> pd.DataFrame:
    """Aggregate exploded motifs into per-sequence motif lists."""
    grouped = (
        exploded.groupby("sequence_index")
        .agg({
            "sequence": "first",
            "motif": lambda vals: sorted(set(v for v in vals if isinstance(v, str) and v)),
        })
        .reset_index()
    )
    grouped.rename(columns={"motif": "motifs"}, inplace=True)
    return grouped


def build_motif_table(exploded: pd.DataFrame, motif_to_sequences: Dict[str, Set[int]]) -> pd.DataFrame:
    """Aggregate per-motif statistics."""
    rows = []
    for motif, seq_indices in motif_to_sequences.items():
        rows.append(
            {
                "core_pattern": motif,
                "original_count": len(seq_indices),
                "total_sequences": len(seq_indices),
                "sequence_indices": sorted(seq_indices),
            }
        )
    motif_df = pd.DataFrame(rows).sort_values("total_sequences", ascending=False).reset_index(drop=True)
    return motif_df


def build_hierarchy(motif_df: pd.DataFrame) -> Tuple[Dict[str, List[str]], Dict[str, str]]:
    """Determine parent-child relationships among motifs."""
    motifs = motif_df["core_pattern"].tolist()
    hierarchy: Dict[str, List[str]] = {}
    parent_map: Dict[str, str] = {}
    for i, parent in enumerate(motifs):
        children = []
        for j, child in enumerate(motifs):
            if i == j:
                continue
            if is_parent_of(parent, child):
                children.append(child)
                current = parent_map.get(child)
                if current is None or len(parent) > len(current):
                    parent_map[child] = parent
        if children:
            hierarchy[parent] = sorted(set(children))
    return hierarchy, parent_map


def consolidate_counts(
    motif_df: pd.DataFrame,
    hierarchy: Dict[str, List[str]],
    motif_to_sequences: Dict[str, Set[int]],
) -> Tuple[pd.DataFrame, Dict[str, Set[int]]]:
    """Roll child sequence counts up to their parents."""
    consolidated = motif_df.copy()
    consolidated["child_motifs"] = ""
    consolidated["num_children"] = 0

    motif_index = {row["core_pattern"]: idx for idx, row in consolidated.iterrows()}

    def gather_descendants(motif: str, seen: Set[str] | None = None) -> List[str]:
        seen = seen or set()
        descendants: List[str] = []
        for child in hierarchy.get(motif, []):
            if child in seen:
                continue
            seen.add(child)
            descendants.append(child)
            descendants.extend(gather_descendants(child, seen))
        return descendants

    for parent, idx in motif_index.items():
        descendants = gather_descendants(parent)
        if not descendants:
            continue
        sequence_union = set(motif_to_sequences.get(parent, set()))
        for child in descendants:
            sequence_union |= motif_to_sequences.get(child, set())
        motif_to_sequences[parent] = sequence_union
        consolidated.at[idx, "total_sequences"] = len(sequence_union)
        consolidated.at[idx, "child_motifs"] = ", ".join(descendants[:10])
        consolidated.at[idx, "num_children"] = len(descendants)

    consolidated = consolidated.sort_values("total_sequences", ascending=False).reset_index(drop=True)
    return consolidated, motif_to_sequences


def build_co_occurrence(sequence_to_motifs: Dict[int, Set[str]]) -> pd.DataFrame:
    """Compute pairwise motif co-occurrence counts."""
    counter: MutableMapping[Tuple[str, str], int] = {}
    for motifs in sequence_to_motifs.values():
        motifs = sorted(motifs)
        if len(motifs) < 2:
            continue
        for a, b in itertools.combinations(motifs, 2):
            counter[(a, b)] = counter.get((a, b), 0) + 1
    if not counter:
        return pd.DataFrame(columns=["source", "target", "shared_sequences"])
    rows = [{"source": a, "target": b, "shared_sequences": count} for (a, b), count in counter.items()]
    return pd.DataFrame(rows)


def summarise_dataset(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> Dict[str, int | float | str]:
    """Return headline metrics for summary cards."""
    if consolidated.empty:
        return {
            "motifs": 0,
            "total_sequences": 0,
            "motifs_with_children": 0,
            "max_children": 0,
            "dataset": "-",
        }
    summary = {
        "motifs": int(len(consolidated)),
        "total_sequences": int(consolidated["total_sequences"].sum()),
        "motifs_with_children": int((consolidated["num_children"] > 0).sum()),
        "max_children": int(consolidated["num_children"].max()),
        "dataset": "sequence upload",
    }
    parent_counts = [len(children) for children in hierarchy.values() if isinstance(children, list)]
    summary["average_children"] = round(sum(parent_counts) / len(parent_counts), 2) if parent_counts else 0.0
    return summary


def calculate_cooccurrence(assignments: pd.DataFrame, motif_patterns: List[str], min_shared: int = 1) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Build full co-occurrence matrix and edge list with association metrics."""
    motif_index = {motif: idx for idx, motif in enumerate(motif_patterns)}
    n = len(motif_patterns)
    matrix = np.zeros((n, n), dtype=int)
    motif_counts = {motif: 0 for motif in motif_patterns}

    for _, row in assignments.iterrows():
        motifs = row.get("motifs", []) or []
        unique_motifs = sorted(set(motifs))
        for motif in unique_motifs:
            idx = motif_index.get(motif)
            if idx is None:
                continue
            motif_counts[motif] = motif_counts.get(motif, 0) + 1
            matrix[idx, idx] += 1
        if len(unique_motifs) < 2:
            continue
        for a, b in itertools.combinations(unique_motifs, 2):
            i, j = motif_index.get(a), motif_index.get(b)
            if i is None or j is None:
                continue
            matrix[i, j] += 1
            matrix[j, i] += 1

    matrix_df = pd.DataFrame(matrix, index=motif_patterns, columns=motif_patterns)

    if min_shared > 1:
        mask = (np.ones_like(matrix_df.values, dtype=bool))
        np.fill_diagonal(mask, False)
        matrix_values = matrix_df.values
        matrix_values[(matrix_values < min_shared) & mask] = 0
        matrix_df = pd.DataFrame(matrix_values, index=motif_patterns, columns=motif_patterns)

    edges = []
    for i in range(n):
        for j in range(i + 1, n):
            shared = matrix_df.iat[i, j]
            if shared < min_shared or shared == 0:
                continue
            motif_i = motif_patterns[i]
            motif_j = motif_patterns[j]
            total_i = motif_counts.get(motif_i, 0)
            total_j = motif_counts.get(motif_j, 0)
            union = total_i + total_j - shared
            jaccard = shared / union if union else 0.0
            cond_i_j = shared / total_j if total_j else 0.0
            cond_j_i = shared / total_i if total_i else 0.0
            edges.append(
                {
                    "source": motif_i,
                    "target": motif_j,
                    "shared_sequences": int(shared),
                    "motif1_total": int(total_i),
                    "motif2_total": int(total_j),
                    "jaccard": float(jaccard),
                    "cond_1_given_2": float(cond_i_j),
                    "cond_2_given_1": float(cond_j_i),
                }
            )

    edges_df = pd.DataFrame(edges)
    return matrix_df, edges_df


def prepare_dataset(path: Path | str, limit: int | None = None) -> Tuple[MotifDataset, List[str]]:
    """Full pipeline from raw CSV to consolidated tables and edges."""
    logger = ProgressLogger()

    logger.log("Loading sequence file")
    sequences = load_sequence_file(path, limit=limit)

    logger.log("Exploding motifs column")
    exploded = explode_motifs(sequences)

    logger.log("Building sequence/motif maps")
    motif_to_sequences, sequence_lookup, sequence_to_motifs = build_sequence_maps(exploded)
    assignments = build_assignments(exploded)

    logger.log("Aggregating motif table")
    motif_table = build_motif_table(exploded, motif_to_sequences)

    logger.log("Computing hierarchy and parent relationships")
    hierarchy, parent_map = build_hierarchy(motif_table)

    logger.log("Consolidating descendant counts")
    consolidated, updated_map = consolidate_counts(motif_table, hierarchy, motif_to_sequences)

    logger.log("Building co-occurrence matrix")
    co_occurrence_matrix, co_occurrence_edges = calculate_cooccurrence(assignments, consolidated["core_pattern"].tolist(), min_shared=1)

    logger.log("Precomputing physicochemical features (this may take a while)")
    start = time.perf_counter()
    calculator = SequencePropertyCalculator()
    features_df = calculator.compute_features(sequence_lookup)
    duration = time.perf_counter() - start
    logger.log(f"Feature computation finished in {duration:.1f}s")

    dataset = MotifDataset(
        sequences=sequences,
        exploded=exploded,
        motif_table=motif_table,
        consolidated_table=consolidated,
        hierarchy=hierarchy,
        parent_map=parent_map,
        motif_to_sequences=updated_map,
        sequence_lookup=sequence_lookup,
        sequence_to_motifs=sequence_to_motifs,
        co_occurrence=co_occurrence_edges,
        co_occurrence_matrix=co_occurrence_matrix,
        sequence_features=features_df,
    )
    return dataset, logger.entries
