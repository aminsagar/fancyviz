from __future__ import annotations

from pathlib import Path
from typing import Iterable, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import dendrogram, linkage, leaves_list
from scipy.spatial.distance import pdist, squareform

from motif_sequence_explorer_mp_3.optimized_app_cluster.data_pipeline import prepare_dataset

DATA_PATH = Path("../sequences_with_motifs_position_independent_p65_consolidated.csv").resolve()
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def _take_top(matrix: pd.DataFrame, counts: pd.Series, top_n: int) -> pd.DataFrame:
    keep = counts.nlargest(top_n).index
    return matrix.loc[keep, keep]


def _log_norm(matrix: pd.DataFrame) -> pd.DataFrame:
    # Symmetric, zero diag; apply log1p for dynamic range compression
    return np.log1p(matrix)


def _cluster_order(matrix: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
    # Use correlation distance on log-transformed weights
    mat = matrix.values
    if mat.shape[0] < 2:
        return np.arange(mat.shape[0]), None
    dist = pdist(mat, metric="correlation")
    Z = linkage(dist, method="average")
    return None, Z


def plot_heatmap(matrix: pd.DataFrame, title: str, outfile: Path):
    # Log transform for visibility
    log_mat = _log_norm(matrix)
    _, Z = _cluster_order(log_mat)
    if Z is not None:
        leaves = dendrogram(Z, no_plot=True, orientation="left")["leaves"]
    else:
        leaves = np.arange(log_mat.shape[0])
    ordered_mat = log_mat.values[leaves][:, leaves]

    fig = plt.figure(figsize=(12, 10))
    gs = fig.add_gridspec(1, 2, width_ratios=[1, 4], wspace=0.05)

    # Single dendrogram on the left
    ax_dendro = fig.add_subplot(gs[0, 0])
    if Z is not None:
        dendrogram(Z, orientation="left", ax=ax_dendro, no_labels=True, color_threshold=None)
        ax_dendro.invert_yaxis()  # align leaf order with heatmap rows
    ax_dendro.set_xticks([])
    ax_dendro.set_yticks([])

    # Heatmap
    ax_heat = fig.add_subplot(gs[0, 1])
    im = ax_heat.imshow(ordered_mat, cmap="magma", aspect="auto", interpolation="nearest")
    ax_heat.set_xticks([])
    ax_heat.set_yticks([])
    ax_heat.set_title(title, fontsize=12)

    cbar = plt.colorbar(im, ax=ax_heat, fraction=0.046, pad=0.02)
    cbar.set_label("log1p(shared sequences)")

    fig.tight_layout()
    fig.savefig(outfile, dpi=200)
    plt.close(fig)


def plot_circular_dendrogram(Z, title: str, outfile: Path):
    if Z is None:
        return
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, polar=True)
    dendrogram(Z, ax=ax, orientation="top", no_labels=True, color_threshold=None)
    ax.set_title(title, fontsize=12, y=1.08)
    ax.set_axis_off()
    fig.savefig(outfile, dpi=200, bbox_inches="tight")
    plt.close(fig)


def main():
    dataset, _ = prepare_dataset(DATA_PATH)
    co_mat = dataset.co_occurrence_matrix
    counts = dataset.consolidated_table.set_index("core_pattern")["total_sequences"]

    # Full heatmap (may be dense but gives overall structure)
    full_out = OUTPUT_DIR / "coocc_heatmap_full.png"
    plot_heatmap(co_mat, "Co-occurrence (full)", full_out)
    _, full_Z = _cluster_order(_log_norm(co_mat))
    circ_full = OUTPUT_DIR / "coocc_circular_full.png"
    plot_circular_dendrogram(full_Z, "Co-occurrence circular (full)", circ_full)
    print(f"Saved {full_out}")
    print(f"Saved {circ_full}")

    # Top-N motifs by total_sequences for a cleaner view
    for top_n in (150, 100, 75, 50):
        trimmed = _take_top(co_mat, counts, top_n)
        out = OUTPUT_DIR / f"coocc_heatmap_top{top_n}.png"
        plot_heatmap(trimmed, f"Co-occurrence (top {top_n} motifs)", out)
        _, Z = _cluster_order(_log_norm(trimmed))
        circ_out = OUTPUT_DIR / f"coocc_circular_top{top_n}.png"
        plot_circular_dendrogram(Z, f"Co-occurrence circular (top {top_n} motifs)", circ_out)
        print(f"Saved {out}")
        print(f"Saved {circ_out}")


if __name__ == "__main__":
    main()
