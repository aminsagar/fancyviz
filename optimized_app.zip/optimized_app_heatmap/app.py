from __future__ import annotations

import base64
import io
import sys
import tempfile
from pathlib import Path
from typing import Dict, List

import dash
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from dash import Dash, Input, Output, State, callback_context, dcc, html, dash_table, no_update
from dash.exceptions import PreventUpdate

PROJECT_ROOT = Path(__file__).resolve().parent
REPO_ROOT = PROJECT_ROOT.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from motif_consolidation import create_interactive_network_pyvis
from .data_pipeline import MotifDataset, prepare_dataset, summarise_dataset
from .figures import (
    create_cooccurrence_network,
    create_dashboard,
    create_heatmap_view,
    create_scatter,
    create_sunburst,
    create_treemap,
)
from .sequence_properties import ScaleCatalog, feature_key

SAMPLE_DATA = PROJECT_ROOT / "data" / "sample_sequences.csv"
FREEZE_SNIPPET = (
    "network = new vis.Network(container, data, options);\n"
    "network.once('afterDrawing', function () {network.setOptions({physics: {enabled: false}});});"
)

catalog = ScaleCatalog()
category_options = [{"label": cat, "value": cat} for cat in catalog.categories()]

def _first_subcategory(category: str | None) -> str | None:
    subs = catalog.subcategories(category) if category else []
    return subs[0] if subs else None

default_x_category = category_options[0]["value"] if category_options else None
default_y_category = category_options[1]["value"] if len(category_options) > 1 else default_x_category
default_x_subcategory = _first_subcategory(default_x_category)
default_y_subcategory = _first_subcategory(default_y_category)


def safe_network_html(network) -> str:
    if network is None:
        return ""
    html_str = ""
    generate_html = getattr(network, "generate_html", None)
    if callable(generate_html):
        for kwargs in ({"notebook": False, "local": False}, {"notebook": False}, {}):
            try:
                html_str = generate_html(**kwargs)
                if html_str:
                    break
            except TypeError:
                continue
    if not html_str:
        tmp = tempfile.NamedTemporaryFile(mode="w+", suffix=".html", delete=False)
        tmp_path = Path(tmp.name)
        tmp.close()
        try:
            network.save_graph(str(tmp_path))
            html_str = tmp_path.read_text(encoding="utf-8")
        finally:
            tmp_path.unlink(missing_ok=True)
    marker = "network = new vis.Network(container, data, options);"
    if marker in html_str:
        html_str = html_str.replace(marker, FREEZE_SNIPPET, 1)
    return html_str


def build_hierarchy_network_html(dataset: MotifDataset) -> str:
    try:
        net = create_interactive_network_pyvis(dataset.hierarchy, dataset.consolidated_table)
    except Exception as exc:  # pragma: no cover
        return f"<p>Hierarchy network unavailable: {exc}</p>"
    return safe_network_html(net)


def _decode_uploaded_csv(contents: str) -> pd.DataFrame:
    if not contents:
        raise ValueError("No file contents provided.")
    _, content_string = contents.split(",", 1)
    decoded = base64.b64decode(content_string)
    try:
        return pd.read_csv(io.StringIO(decoded.decode("utf-8")))
    except UnicodeDecodeError:
        return pd.read_csv(io.BytesIO(decoded))


def _dataset_to_payload(dataset: MotifDataset, source_label: str) -> Dict:
    consolidated = dataset.consolidated_table
    summary = summarise_dataset(consolidated, dataset.hierarchy)
    summary["dataset"] = source_label
    network_html = build_hierarchy_network_html(dataset)
    feature_df = dataset.sequence_features.set_index("sequence_index") if not dataset.sequence_features.empty else pd.DataFrame()
    feature_map = feature_df.to_dict(orient="index") if not feature_df.empty else {}
    return {
        "summary": summary,
        "consolidated": consolidated.to_dict("records"),
        "columns": list(consolidated.columns),
        "hierarchy": dataset.hierarchy,
        "parent_map": dataset.parent_map,
        "co_occurrence": dataset.co_occurrence.to_dict("records"),
        "co_occurrence_matrix": dataset.co_occurrence_matrix.to_dict(),
        "motif_sequences": {motif: sorted(seq_ids) for motif, seq_ids in dataset.motif_to_sequences.items()},
        "sequence_lookup": {str(idx): seq for idx, seq in dataset.sequence_lookup.items()},
        "sequence_to_motifs": {str(idx): sorted(list(motifs)) for idx, motifs in dataset.sequence_to_motifs.items()},
        "network_html": network_html,
        "sequence_features": {str(idx): feats for idx, feats in feature_map.items()},
    }


def _empty_payload(message: str) -> Dict:
    return {
        "summary": {"dataset": message},
        "consolidated": [],
        "columns": [],
        "hierarchy": {},
        "co_occurrence": [],
        "co_occurrence_matrix": {},
        "motif_sequences": {},
        "network_html": "",
        "sequence_features": {},
        "sequence_lookup": {},
        "sequence_to_motifs": {},
    }


def _load_or_raise(path: Path, limit: int | None = None):
    return prepare_dataset(path, limit=limit)

try:
    default_dataset, default_logs = _load_or_raise(SAMPLE_DATA)
    default_payload = _dataset_to_payload(default_dataset, SAMPLE_DATA.name)
    default_message = f"Loaded sample dataset ({SAMPLE_DATA.name}, rows: {len(default_dataset.sequences)})"
    default_logs_text = "\n".join(default_logs)
except Exception as exc:  # pragma: no cover
    default_payload = _empty_payload(str(exc))
    default_message = f"Sample dataset unavailable: {exc}"
    default_logs_text = str(exc)

app = Dash(__name__, suppress_callback_exceptions=True)
app.title = "Sequence Motif Explorer"
app.config.suppress_callback_exceptions = True

app.layout = html.Div(
    [
        dcc.Location(id="url", refresh=False),
        dcc.Store(id="analysis-store", data=default_payload),
        dcc.Store(id="shortlist-store", data={}),
        dcc.Store(id="motif-subset-store", data=[]),
        dcc.Store(id="sidebar-collapsed", data=False),
        html.Div(
            id="app-shell",
            className="app-shell",
            children=[
                html.Div(
                    id="sidebar",
                    className="sidebar",
                    children=[
                        html.Button("Collapse sidebar", id="toggle-sidebar", className="sidebar-toggle", n_clicks=0),
                        html.Div(
                            [
                                html.Div("Motif explorer", className="kicker"),
                                html.H1("Sequence Insight", className="brand-title"),
                                html.P(
                                    "Compare motifs, examine hierarchy, and explore physicochemical properties.",
                                    className="muted",
                                ),
                            ],
                            className="brand-block",
                        ),
                        html.Nav(
                            [
                                dcc.Link(
                                    [html.Span("Overview", className="nav-label")],
                                    href="/",
                                    className="nav-link",
                                    id="nav-overview",
                                    title="Overview",
                                ),
                                dcc.Link(
                                    [html.Span("Analysis", className="nav-label")],
                                    href="/analysis",
                                    className="nav-link",
                                    id="nav-analysis",
                                    title="Analysis",
                                ),
                            ],
                            className="nav-links",
                        ),
                        html.Div(
                            [
                                html.Div("Tips", className="muted"),
                                html.Ul(
                                    [
                                        html.Li("Load a CSV or start with the sample dataset."),
                                        html.Li("Use lasso on the plots to shortlist sequences."),
                                    ],
                                    className="tip-list",
                                ),
                            ],
                            className="sidebar-note",
                        ),
                    ],
                ),
                html.Div(
                    className="content-area",
                    children=[
                        html.Div(id="page-content", className="page-content"),
                    ],
                ),
            ],
        ),
    ],
    className="app-root",
)


@app.callback(
    Output("sidebar-collapsed", "data"),
    Input("toggle-sidebar", "n_clicks"),
    State("sidebar-collapsed", "data"),
    prevent_initial_call=True,
)
def toggle_sidebar(n_clicks, collapsed):
    if n_clicks is None:
        raise PreventUpdate
    return not bool(collapsed)


@app.callback(
    Output("sidebar", "className"),
    Output("app-shell", "className"),
    Output("toggle-sidebar", "children"),
    Input("sidebar-collapsed", "data"),
)
def sync_sidebar_state(collapsed):
    is_collapsed = bool(collapsed)
    sidebar_class = "sidebar sidebar--collapsed" if is_collapsed else "sidebar"
    shell_class = "app-shell app-shell--collapsed" if is_collapsed else "app-shell"
    button_label = "Expand sidebar" if is_collapsed else "Collapse sidebar"
    return sidebar_class, shell_class, button_label


@app.callback(
    Output("analysis-store", "data"),
    Output("status-message", "children"),
    Output("progress-log", "children"),
    Input("upload-data", "contents"),
    Input("use-sample-btn", "n_clicks"),
    State("upload-data", "filename"),
    State("row-limit", "value"),
    prevent_initial_call=True,
)
def update_dataset(contents, sample_clicks, filename, row_limit):
    ctx = callback_context
    if not ctx.triggered:
        raise PreventUpdate
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]
    try:
        limit = int(row_limit) if row_limit else None
        if trigger == "use-sample-btn":
            dataset, logs = _load_or_raise(SAMPLE_DATA, limit=limit)
            payload = _dataset_to_payload(dataset, SAMPLE_DATA.name)
            status = f"Loaded sample dataset (rows: {len(dataset.sequences)})"
            return payload, status, "\n".join(logs)
        if trigger == "upload-data":
            raw_df = _decode_uploaded_csv(contents)
            with tempfile.NamedTemporaryFile(mode="w+", suffix=".csv", delete=False) as tmp:
                raw_df.to_csv(tmp.name, index=False)
                temp_path = Path(tmp.name)
            dataset, logs = _load_or_raise(temp_path, limit=limit)
            payload = _dataset_to_payload(dataset, filename or "Upload")
            status = f"Loaded upload ({filename}) rows: {len(dataset.sequences)}"
            temp_path.unlink(missing_ok=True)
            return payload, status, "\n".join(logs)
    except Exception as exc:
        return no_update, f"Failed to load dataset: {exc}", no_update
    raise PreventUpdate


def create_overview_layout():
    """Overview page layout"""
    return html.Div(
        className="page-body",
        children=[
            html.Div(
                className="card upload-card",
                children=[
                    dcc.Upload(
                        id="upload-data",
                        children=html.Div(["Drag and drop or ", html.A("select a CSV file")]),
                        className="upload-dropzone",
                        multiple=False,
                    ),
                    html.Div(
                        [
                            html.Button("Use Sample Dataset", id="use-sample-btn", n_clicks=0, className="primary-btn"),
                            html.Div(
                                [
                                    html.Label("Row limit (optional)"),
                                    dcc.Input(id="row-limit", type="number", placeholder="e.g., 1000", min=50, className="input-compact"),
                                ],
                                className="input-stack",
                            ),
                        ],
                        className="control-row",
                    ),
                    html.Div(id="status-message", className="status-message"),
                    html.Pre(id="progress-log", className="progress-log"),
                ],
            ),
            html.Div(id="summary-cards", className="summary-grid"),
            html.Div(
                className="card table-card",
                children=[
                    html.Div([html.H3("Consolidated Motifs")], className="section-header"),
                    dash_table.DataTable(
                        id="motif-table",
                        page_size=15,
                        style_table={"overflowX": "auto"},
                        style_cell={"textAlign": "left", "padding": "8px", "border": "1px solid #1f2a44", "color": "#e5e7eb"},
                        style_header={"backgroundColor": "#162135", "color": "#e5e7eb", "fontWeight": "bold", "border": "1px solid #24334e"},
                        style_data={"lineHeight": "20px", "backgroundColor": "transparent"},
                    ),
                ],
            ),
            html.Div(
                className="card tab-card",
                children=[
                    html.Div([html.H3("Composition Views")], className="section-header"),
                    dcc.Tabs(
                        [
                            dcc.Tab(label="Dashboard", children=dcc.Graph(id="dashboard-graph"), className="tab-item", selected_className="tab-item--selected"),
                            dcc.Tab(label="Sunburst", children=dcc.Graph(id="sunburst-graph"), className="tab-item", selected_className="tab-item--selected"),
                            dcc.Tab(label="Treemap", children=dcc.Graph(id="treemap-graph"), className="tab-item", selected_className="tab-item--selected"),
                            dcc.Tab(label="Scatter", children=dcc.Graph(id="scatter-graph"), className="tab-item", selected_className="tab-item--selected"),
                        ],
                        className="plot-tabs",
                    ),
                ],
            ),
            html.Div(
                className="card network-card",
                children=[
                    html.Div([html.H3("Hierarchy Network")], className="section-header"),
                    html.Iframe(id="hierarchy-network", className="network-frame"),
                ],
            ),
        ],
    )


def create_analysis_layout():
    """Analysis page layout with side-by-side co-occurrence and physicochemical plots"""
    return html.Div(
        className="page-body",
        children=[
            html.Div(
                className="card analysis-panel analysis-top",
                children=[
                    html.Div([html.H3("Motif Co-occurrence Network")], className="section-header"),
                    html.Label("Minimum shared sequences", className="muted"),
                    dcc.Slider(
                        id="coocc-threshold",
                        min=1,
                        max=200,
                        step=1,
                        value=50,
                        marks={10: "10", 50: "50", 100: "100", 150: "150", 200: "200"},
                    ),
                    dcc.Graph(id="cooccurrence-network", style={"height": "520px"}, className="graph-block"),
                ],
            ),
            html.Div(
                className="card analysis-panel",
                children=[
                    html.Div([html.H3("Motif Map (Heatmap)")], className="section-header"),
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.Label("Top motifs"),
                                    dcc.Dropdown(
                                        id="heatmap-top-n",
                                        options=[{"label": str(n), "value": n} for n in (50, 75, 100, 150)],
                                        value=75,
                                        clearable=False,
                                        className="dropdown-compact",
                                    ),
                                ],
                                className="control-column",
                            ),
                            html.Div(
                                [
                                    html.Label("Min shared sequences"),
                                    dcc.Slider(
                                        id="heatmap-min-shared",
                                        min=1,
                                        max=100,
                                        step=1,
                                        value=5,
                                        marks={1: "1", 5: "5", 10: "10", 50: "50", 100: "100"},
                                    ),
                                ],
                                className="control-column",
                            ),
                        ],
                        className="control-grid",
                    ),
                    dcc.Graph(id="heatmap-graph", style={"height": "720px"}, className="graph-block"),
                ],
            ),
            html.Div(
                className="card analysis-controls",
                children=[
                    html.Div([html.H3("Axis Selection")], className="section-header"),
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.Strong("X-axis"),
                                    dcc.Dropdown(
                                        id="x-category",
                                        options=category_options,
                                        value=default_x_category,
                                        clearable=False,
                                        placeholder="Select category",
                                    ),
                                    dcc.Dropdown(
                                        id="x-subcategory",
                                        options=[{"label": default_x_subcategory, "value": default_x_subcategory}] if default_x_subcategory else [],
                                        value=default_x_subcategory,
                                        clearable=False,
                                        placeholder="Select subcategory",
                                    ),
                                ],
                                className="control-column",
                            ),
                            html.Div(
                                [
                                    html.Strong("Y-axis"),
                                    dcc.Dropdown(
                                        id="y-category",
                                        options=category_options,
                                        value=default_y_category,
                                        clearable=False,
                                        placeholder="Select category",
                                    ),
                                    dcc.Dropdown(
                                        id="y-subcategory",
                                        options=[{"label": default_y_subcategory, "value": default_y_subcategory}] if default_y_subcategory else [],
                                        value=default_y_subcategory,
                                        clearable=False,
                                        placeholder="Select subcategory",
                                    ),
                                ],
                                className="control-column",
                            ),
                        ],
                        className="control-grid",
                    ),
                ],
            ),
            html.Div(
                className="analysis-row",
                children=[
                    html.Div(
                        className="card analysis-panel",
                        children=[
                            html.Div([html.H3("Sequence Scale Distribution")], className="section-header"),
                            html.Div(id="scale-info", className="muted"),
                            html.Div("Click a node in the co-occurrence network to view the projection of its sequences.", className="helper-text"),
                            dcc.Graph(id="scale-scatter", style={"height": "360px"}, className="graph-block"),
                        ],
                    ),
                    html.Div(
                        className="card analysis-panel",
                        children=[
                            html.Div([html.H3("Shortlisted Sequences")], className="section-header"),
                            html.Div(
                                [
                                    html.Button("Download Shortlist", id="download-shortlist-btn", className="primary-btn"),
                                    html.Button("Clear Shortlist", id="clear-shortlist-btn", className="ghost-btn"),
                                    html.Span(id="shortlist-count", className="shortlist-count"),
                                ],
                                className="shortlist-actions",
                            ),
                            dcc.Graph(id="shortlist-scatter", style={"height": "360px"}, className="graph-block"),
                            dcc.Download(id="shortlist-download"),
                        ],
                    ),
                ],
            ),
        ],
    )


@app.callback(
    Output("page-content", "children"),
    Input("url", "pathname"),
)
def display_page(pathname):
    if pathname == "/analysis":
        return create_analysis_layout()
    else:
        return create_overview_layout()


@app.callback(
    Output("nav-overview", "className"),
    Output("nav-analysis", "className"),
    Input("url", "pathname"),
)
def update_nav_classes(pathname):
    base = "nav-link"
    if pathname == "/analysis":
        return base, f"{base} active"
    return f"{base} active", base


@app.callback(
    Output("summary-cards", "children"),
    Output("motif-table", "data"),
    Output("motif-table", "columns"),
    Output("dashboard-graph", "figure"),
    Output("sunburst-graph", "figure"),
    Output("treemap-graph", "figure"),
    Output("scatter-graph", "figure"),
    Output("hierarchy-network", "srcDoc"),
    Input("analysis-store", "data"),
)
def refresh_visuals(data):
    if not data or not data.get("consolidated"):
        raise PreventUpdate
    consolidated = pd.DataFrame(data["consolidated"])
    summary = data.get("summary", {})
    hierarchy = data.get("hierarchy", {})
    cards = []
    card_items = [
        ("Dataset", summary.get("dataset", "-")),
        ("Motifs", f"{summary.get('motifs', 0):,}"),
        ("Total sequences", f"{summary.get('total_sequences', 0):,}"),
        ("Motifs with children", f"{summary.get('motifs_with_children', 0):,}"),
        ("Max children", f"{summary.get('max_children', 0):,}"),
        ("Average children", f"{summary.get('average_children', 0.0):.2f}"),
    ]
    for title, value in card_items:
        cards.append(
            html.Div(
                [html.Div(title, className="summary-title"), html.Div(value, className="summary-value")],
                className="summary-card card",
            )
        )
    table_columns = [
        {"name": col.replace("_", " ").title(), "id": col}
        for col in ["core_pattern", "original_count", "total_sequences", "num_children", "child_motifs"]
        if col in consolidated.columns
    ]
    table_data = consolidated[[col["id"] for col in table_columns]].to_dict("records") if table_columns else []

    dashboard_fig = create_dashboard(consolidated)
    sunburst_fig = create_sunburst(consolidated, hierarchy)
    treemap_fig = create_treemap(consolidated, hierarchy)
    scatter_fig = create_scatter(consolidated)
    network_html = data.get("network_html", "")
    return cards, table_data, table_columns, dashboard_fig, sunburst_fig, treemap_fig, scatter_fig, network_html


@app.callback(
    Output("cooccurrence-network", "figure"),
    Input("analysis-store", "data"),
    Input("coocc-threshold", "value"),
)
def update_cooccurrence(data, threshold):
    if not data or not data.get("consolidated"):
        raise PreventUpdate
    consolidated = pd.DataFrame(data["consolidated"])
    co_occ_df = pd.DataFrame(data.get("co_occurrence", []))
    if co_occ_df.empty:
        co_occ_df = pd.DataFrame(columns=["source", "target", "shared_sequences"])
    fig, _ = create_cooccurrence_network(consolidated, co_occ_df, threshold or 50)
    return fig


@app.callback(
    Output("heatmap-graph", "figure"),
    Input("analysis-store", "data"),
    Input("heatmap-top-n", "value"),
    Input("heatmap-min-shared", "value"),
)
def update_heatmap_view(data, top_n, min_shared):
    if not data or not data.get("co_occurrence_matrix"):
        raise PreventUpdate
    co_mat = pd.DataFrame(data["co_occurrence_matrix"])
    consolidated = pd.DataFrame(data["consolidated"])
    if co_mat.empty or consolidated.empty:
        raise PreventUpdate
    counts = consolidated.set_index("core_pattern")["total_sequences"]
    return create_heatmap_view(co_mat, counts, top_n=top_n or 75, min_shared=min_shared or 1)


def _subcategory_options(category: str | None):
    subs = catalog.subcategories(category) if category else []
    options = [{"label": sub, "value": sub} for sub in subs]
    value = options[0]["value"] if options else None
    return options, value


@app.callback(
    Output("x-subcategory", "options"),
    Output("x-subcategory", "value"),
    Input("x-category", "value"),
)
def update_x_subcategory(category):
    return _subcategory_options(category)


@app.callback(
    Output("y-subcategory", "options"),
    Output("y-subcategory", "value"),
    Input("y-category", "value"),
)
def update_y_subcategory(category):
    return _subcategory_options(category)


@app.callback(
    Output("scale-scatter", "figure"),
    Output("scale-info", "children"),
    Output("motif-subset-store", "data"),
    Input("cooccurrence-network", "clickData"),
    Input("analysis-store", "data"),
    Input("x-category", "value"),
    Input("x-subcategory", "value"),
    Input("y-category", "value"),
    Input("y-subcategory", "value"),
)
def update_scale_distribution(click_data, data, x_cat, x_sub, y_cat, y_sub):
    if not data or not data.get("consolidated"):
        raise PreventUpdate
    if not click_data or "points" not in click_data:
        raise PreventUpdate
    if not x_cat or not x_sub or not y_cat or not y_sub:
        raise PreventUpdate
    feature_map = data.get("sequence_features", {})
    if not feature_map:
        raise PreventUpdate
    try:
        feature_df = pd.DataFrame.from_dict({int(idx): feats for idx, feats in feature_map.items()}, orient="index")
    except ValueError:
        feature_df = pd.DataFrame.from_dict(feature_map, orient="index")
        feature_df.index = feature_df.index.astype(int)
    if feature_df.empty:
        raise PreventUpdate

    x_key = feature_key(x_cat, x_sub)
    y_key = feature_key(y_cat, y_sub)
    if x_key not in feature_df.columns or y_key not in feature_df.columns:
        fig = go.Figure()
        fig.add_annotation(text="No data available for the selected categories.", showarrow=False)
        fig.update_layout(template="plotly_dark", height=360, margin=dict(l=60, r=30, t=30, b=50))
        return fig, "Categories not available in feature set.", []

    background = feature_df[[x_key, y_key]].dropna()
    seq_lookup = data.get("sequence_lookup", {})
    sequence_to_motifs = data.get("sequence_to_motifs", {})

    motif = click_data["points"][0].get("customdata") or click_data["points"][0].get("text")
    if not motif:
        raise PreventUpdate
    motif_sequences = data.get("motif_sequences", {})
    seq_indices = motif_sequences.get(motif)
    if not seq_indices:
        fig = go.Figure()
        fig.add_annotation(text="No sequences recorded for motif.", showarrow=False)
        fig.update_layout(template="plotly_dark", height=360, margin=dict(l=60, r=30, t=30, b=50))
        return fig, f"No sequences recorded for {motif}", []

    if not background.empty:
        subset = background.loc[background.index.intersection(seq_indices)]
    else:
        subset = pd.DataFrame()
    subset = subset.dropna()

    subset_records = []
    fig = go.Figure()
    if not background.empty:
        sample = background.sample(min(len(background), 6000), random_state=42)
        fig.add_trace(
            go.Scattergl(
                x=sample[x_key],
                y=sample[y_key],
                mode="markers",
                marker=dict(size=4, color="rgba(200,200,200,0.3)"),
                hoverinfo="skip",
                name="All sequences",
            )
        )

    if subset.empty:
        fig.add_annotation(text="No overlapping sequences for motif in selected axes.", showarrow=False)
        fig.update_layout(template="plotly_dark", height=520)
        return fig, f"{motif}: no data for selected axes.", []

    for idx in subset.index:
        subset_records.append(
            {
                "sequence_index": int(idx),
                "sequence": seq_lookup.get(str(idx), ""),
                "motifs": sequence_to_motifs.get(str(idx), []),
                "features": feature_map.get(str(idx), {}),
                "selected_motif": motif,
            }
        )

    fig.add_trace(
        go.Scattergl(
            x=subset[x_key],
            y=subset[y_key],
            mode="markers",
            text=[seq_lookup.get(str(idx), f"Seq {idx}") for idx in subset.index],
            hovertemplate="Sequence: %{text}<br>X: %{x:.3f}<br>Y: %{y:.3f}<extra></extra>",
            marker=dict(size=11, color="#4ecdc4", line=dict(color="#1f2630", width=1.2)),
            customdata=[int(idx) for idx in subset.index],
            name=motif,
        )
    )

    fig.update_layout(
        template="plotly_dark",
        height=360,
        margin=dict(l=60, r=30, t=30, b=50),
        xaxis_title=f"{x_cat} – {x_sub}",
        yaxis_title=f"{y_cat} – {y_sub}",
        dragmode="lasso",
        uirevision="scale-scatter",
    )

    info = f"{motif}: {len(subset)} sequences plotted (background: {len(background)})."
    return fig, info, subset_records


@app.callback(
    Output("shortlist-scatter", "figure"),
    Output("shortlist-count", "children"),
    Input("shortlist-store", "data"),
    Input("analysis-store", "data"),
    Input("x-category", "value"),
    Input("x-subcategory", "value"),
    Input("y-category", "value"),
    Input("y-subcategory", "value"),
)
def render_shortlist(shortlist, data, x_cat, x_sub, y_cat, y_sub):
    fig = go.Figure()
    if not data or not data.get("sequence_features") or not x_cat or not x_sub or not y_cat or not y_sub:
        fig.update_layout(template="plotly_dark", height=320, margin=dict(l=60, r=30, t=30, b=50))
        return fig, "Shortlist: 0 sequences"
    feature_map = data.get("sequence_features", {})
    feature_df = pd.DataFrame.from_dict({int(idx): feats for idx, feats in feature_map.items()}, orient="index")
    x_key = feature_key(x_cat, x_sub)
    y_key = feature_key(y_cat, y_sub)
    if x_key not in feature_df.columns or y_key not in feature_df.columns:
        fig.add_annotation(text="Selected categories are unavailable for shortlist.", showarrow=False)
        fig.update_layout(template="plotly_dark", height=320, margin=dict(l=60, r=30, t=30, b=50))
        return fig, "Shortlist: 0 sequences"

    background = feature_df[[x_key, y_key]].dropna()
    if not background.empty:
        fig.add_trace(
            go.Scattergl(
                x=background[x_key],
                y=background[y_key],
                mode="markers",
                marker=dict(size=4, color="rgba(200,200,200,0.2)"),
                hoverinfo="skip",
                name="All sequences",
            )
        )

    shortlist = shortlist or {}
    seq_lookup = data.get("sequence_lookup", {})
    motif_groups = {}
    for key, entry in shortlist.items():
        feats = entry.get("features", {})
        x_val = feats.get(x_key)
        y_val = feats.get(y_key)
        if x_val is None or y_val is None or np.isnan(x_val) or np.isnan(y_val):
            continue
        seq_id = entry.get("sequence_index", key)
        seq_text = entry.get("sequence") or seq_lookup.get(str(seq_id), f"Seq {seq_id}")
        motif_label = entry.get("selected_motif") or (entry.get("motifs") or ["Shortlist"])[0] or "Shortlist"
        motif_groups.setdefault(motif_label, {"x": [], "y": [], "text": []})
        motif_groups[motif_label]["x"].append(x_val)
        motif_groups[motif_label]["y"].append(y_val)
        motif_groups[motif_label]["text"].append(seq_text)

    palette = ["#ff4958", "#4ecdc4", "#7dd3fc", "#f5b700", "#b18aff", "#ffaa91", "#3dd598", "#e17055"]
    if motif_groups:
        for motif_label in sorted(motif_groups.keys()):
            color_index = sum(ord(ch) for ch in motif_label) % len(palette)
            color = palette[color_index]
            group = motif_groups[motif_label]
            fig.add_trace(
                go.Scattergl(
                    x=group["x"],
                    y=group["y"],
                    mode="markers",
                    marker=dict(size=12, color=color, line=dict(color="#1f2630", width=1.2)),
                    text=group["text"],
                    hovertemplate="Sequence: %{text}<br>X: %{x:.3f}<br>Y: %{y:.3f}<extra></extra>",
                    name=motif_label,
                )
            )
    else:
        fig.add_annotation(text="No shortlisted sequences yet.", showarrow=False)

    fig.update_layout(
        template="plotly_dark",
        height=320,
        margin=dict(l=60, r=30, t=30, b=50),
        xaxis_title=f"{x_cat} – {x_sub}",
        yaxis_title=f"{y_cat} – {y_sub}",
        dragmode="lasso",
        uirevision="shortlist-scatter",
    )
    return fig, f"Shortlist: {len(shortlist)} sequences"


@app.callback(
    Output("shortlist-store", "data"),
    Input("scale-scatter", "clickData"),
    Input("scale-scatter", "selectedData"),
    Input("clear-shortlist-btn", "n_clicks"),
    State("shortlist-store", "data"),
    State("motif-subset-store", "data"),
    prevent_initial_call=True,
)
def update_shortlist(click_data, selected_data, clear_clicks, shortlist, subset_data):
    ctx = callback_context
    if shortlist is None:
        shortlist = {}
    subset_lookup = {item["sequence_index"]: item for item in (subset_data or []) if item.get("sequence_index") is not None}
    if not ctx.triggered:
        raise PreventUpdate
    trigger = ctx.triggered[0]["prop_id"].split(".")[0]
    updated = dict(shortlist)

    def toggle_sequence(seq_id):
        key = str(seq_id)
        if key in updated:
            updated.pop(key, None)
        elif seq_id in subset_lookup:
            updated[key] = subset_lookup[seq_id]

    if trigger == "clear-shortlist-btn":
        return {}

    if trigger == "scale-scatter":
        if click_data and "points" in click_data and click_data["points"]:
            seq_id = click_data["points"][0].get("customdata")
            if seq_id is not None:
                toggle_sequence(int(seq_id))
        if selected_data and "points" in selected_data:
            for point in selected_data["points"]:
                seq_id = point.get("customdata")
                if seq_id is not None:
                    toggle_sequence(int(seq_id))
        return updated

    raise PreventUpdate


@app.callback(
    Output("shortlist-download", "data"),
    Input("download-shortlist-btn", "n_clicks"),
    State("shortlist-store", "data"),
    prevent_initial_call=True,
)
def download_shortlist(n_clicks, shortlist):
    if not n_clicks or not shortlist:
        raise PreventUpdate
    rows = []
    for entry in shortlist.values():
        row = {
            "sequence_index": entry.get("sequence_index"),
            "sequence": entry.get("sequence", ""),
            "motifs": ";".join(entry.get("motifs") or []),
        }
        for feature, value in (entry.get("features") or {}).items():
            row[feature] = value
        rows.append(row)
    if not rows:
        raise PreventUpdate
    df = pd.DataFrame(rows)
    return dcc.send_data_frame(df.to_csv, "shortlist.csv", index=False)


if __name__ == "__main__":
    # Set debug=False to hide startup warnings, or debug=True for hot reloading during development
    import os
    debug_mode = os.environ.get("DASH_DEBUG", "true").lower() == "true"
    app.run(debug=debug_mode)
