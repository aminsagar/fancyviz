from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

import networkx as nx
from networkx.algorithms import community
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def _node_sizes(values: Iterable[int], min_size: int = 10, max_size: int = 40) -> List[float]:
    scaled = []
    for value in values:
        size = np.log1p(value) * 6
        size = max(min_size, min(max_size, size))
        scaled.append(size)
    return scaled


def create_dashboard(consolidated: pd.DataFrame) -> go.Figure:
    """Recreate a compact dashboard similar to the original app."""
    if consolidated.empty:
        fig = make_subplots(rows=1, cols=1)
        fig.add_annotation(text="No motifs available", showarrow=False)
        return fig

    df = consolidated.copy()
    df["increase_pct"] = np.where(
        df["original_count"] > 0,
        (df["total_sequences"] - df["original_count"]) / df["original_count"] * 100,
        0,
    )
    df["motif_length"] = df["core_pattern"].str.len()

    fig = make_subplots(
        rows=2,
        cols=2,
        subplot_titles=(
            "Top Motifs (Consolidated vs Original)",
            "Count Increase Distribution",
            "Children Distribution",
            "Motif Length vs Count",
        ),
        specs=[[{"type": "bar"}, {"type": "histogram"}], [{"type": "bar"}, {"type": "scatter"}]],
    )

    top = df.head(20)
    fig.add_trace(
        go.Bar(x=top["core_pattern"], y=top["total_sequences"], name="Consolidated", marker_color="#4ecdc4"),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Bar(x=top["core_pattern"], y=top["original_count"], name="Original", marker_color="#ff6b6b"),
        row=1,
        col=1,
    )

    increases = df["increase_pct"]
    increases = increases[np.isfinite(increases) & (increases > 0)]
    fig.add_trace(
        go.Histogram(x=increases, nbinsx=30, marker_color="#feca57", name="Increase %"),
        row=1,
        col=2,
    )

    children_counts = df["num_children"].value_counts().sort_index()
    fig.add_trace(
        go.Bar(x=children_counts.index, y=children_counts.values, marker_color="#845ec2", name="# children"),
        row=2,
        col=1,
    )

    fig.add_trace(
        go.Scatter(
            x=df["motif_length"],
            y=df["total_sequences"],
            mode="markers",
            text=df["core_pattern"],
            marker=dict(
                size=_node_sizes(df["num_children"].fillna(0) + 1, min_size=8, max_size=28),
                color=df["num_children"],
                colorscale="Viridis",
                showscale=True,
                colorbar=dict(title="Children", x=1.15),
            ),
            name="Motifs",
        ),
        row=2,
        col=2,
    )

    fig.update_layout(template="plotly_dark", height=800, showlegend=True)
    fig.update_xaxes(tickangle=45, row=1, col=1)
    fig.update_yaxes(type="log", row=2, col=2)
    return fig


def _build_tree_labels(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> Tuple[List[str], List[str]]:
    parents = []
    for motif in consolidated["core_pattern"]:
        parent = None
        for potential_parent, children in hierarchy.items():
            if not isinstance(children, list):
                continue
            if motif in children:
                if parent is None or len(potential_parent) > len(parent):
                    parent = potential_parent
        parents.append(parent if parent else "All Motifs")
    labels = consolidated["core_pattern"].tolist()
    return labels, parents


def create_sunburst(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> go.Figure:
    if consolidated.empty:
        return go.Figure()
    labels, parents = _build_tree_labels(consolidated, hierarchy)
    fig = go.Figure(
        go.Sunburst(
            labels=["All Motifs"] + labels,
            parents=[""] + parents,
            values=[consolidated["total_sequences"].sum()] + consolidated["original_count"].tolist(),
            marker=dict(colors=[0] + consolidated["total_sequences"].tolist(), colorscale="Viridis"),
            hovertemplate="<b>%{label}</b><br>Original: %{value}<extra></extra>",
            branchvalues="total",
        )
    )
    fig.update_layout(template="plotly_dark", height=700, margin=dict(t=10, l=10, r=10, b=10))
    return fig


def create_treemap(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> go.Figure:
    if consolidated.empty:
        return go.Figure()
    labels, parents = _build_tree_labels(consolidated, hierarchy)
    fig = go.Figure(
        go.Treemap(
            labels=["All Motifs"] + labels,
            parents=[""] + parents,
            values=[consolidated["total_sequences"].sum()] + consolidated["total_sequences"].tolist(),
            marker=dict(colors=[0] + consolidated["total_sequences"].tolist(), colorscale="Blues"),
            hovertemplate="<b>%{label}</b><br>Total: %{value}<extra></extra>",
        )
    )
    fig.update_layout(template="plotly_dark", height=700, margin=dict(t=10, l=10, r=10, b=10))
    return fig


def create_scatter(consolidated: pd.DataFrame) -> go.Figure:
    if consolidated.empty:
        return go.Figure()
    fig = go.Figure(
        go.Scatter(
            x=consolidated["original_count"].replace(0, np.nan),
            y=consolidated["total_sequences"],
            text=consolidated["core_pattern"],
            mode="markers",
            marker=dict(
                size=_node_sizes(consolidated["num_children"].fillna(0) + 1),
                color=consolidated["num_children"],
                colorscale="Turbo",
                showscale=True,
                colorbar=dict(title="Children"),
            ),
        )
    )
    fig.update_layout(
        template="plotly_dark",
        height=600,
        xaxis_title="Original count",
        yaxis_title="Consolidated count",
        xaxis_type="log",
        yaxis_type="log",
    )
    return fig


def _component_layout(graph: nx.Graph, weight: str | None = None, spacing: float = 3.5) -> Dict[str, Tuple[float, float]]:
    """Lay out each connected component separately to avoid circular artifact."""
    positions: Dict[str, Tuple[float, float]] = {}
    offset_x = 0.0
    components = list(nx.connected_components(graph))
    if not components:
        return positions
    for comp in components:
        sub = graph.subgraph(comp)
        if sub.number_of_nodes() == 1:
            node = next(iter(sub.nodes))
            positions[node] = (offset_x, 0.0)
            offset_x += spacing
            continue
        try:
            sub_pos = nx.spring_layout(sub, seed=42, weight=weight, iterations=500)
        except Exception:  # pragma: no cover - fallback if spring_layout fails
            sub_pos = nx.kamada_kawai_layout(sub, weight=weight)
        min_x = min(coord[0] for coord in sub_pos.values())
        max_x = max(coord[0] for coord in sub_pos.values())
        width = max(1.0, max_x - min_x)
        for node, (x, y) in sub_pos.items():
            positions[node] = (x - min_x + offset_x, y)
        offset_x += width + spacing
    return positions


def _network_figure(
    graph: nx.Graph,
    positions: Dict[str, Tuple[float, float]],
    node_sizes: Dict[str, float],
    node_colors: Dict[str, float],
    title: str,
) -> go.Figure:
    edge_x: List[float] = []
    edge_y: List[float] = []
    for u, v in graph.edges():
        x0, y0 = positions[u]
        x1, y1 = positions[v]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])

    edge_trace = go.Scatter(
        x=edge_x,
        y=edge_y,
        mode="lines",
        line=dict(width=1, color="rgba(200,200,200,0.5)"),
        hoverinfo="none",
    )

    node_trace = go.Scatter(
        x=[positions[node][0] for node in graph.nodes()],
        y=[positions[node][1] for node in graph.nodes()],
        mode="markers+text",
        text=list(graph.nodes()),
        textposition="bottom center",
        textfont=dict(size=11, color="#FFFFFF"),
        hovertext=[
            f"{node}<br>Count: {graph.nodes[node].get('count', 0):,}" for node in graph.nodes()
        ],
        hoverinfo="text",
        customdata=list(graph.nodes()),
        marker=dict(
            size=[node_sizes.get(node, 15) for node in graph.nodes()],
            color=[node_colors.get(node, 0) for node in graph.nodes()],
            colorscale="Viridis",
            showscale=True,
            colorbar=dict(title="Count"),
            line=dict(color="#1f2630", width=1),
        ),
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        template="plotly_dark",
        title=title,
        showlegend=False,
        margin=dict(t=40, b=20, l=20, r=20),
        xaxis=dict(showgrid=False, zeroline=False, visible=False),
        yaxis=dict(showgrid=False, zeroline=False, visible=False),
    )
    return fig


def create_hierarchy_network(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> go.Figure:
    graph = nx.DiGraph()
    for _, row in consolidated.iterrows():
        graph.add_node(row["core_pattern"], count=int(row["total_sequences"]))
    for parent, children in hierarchy.items():
        for child in children:
            if parent in graph and child in graph:
                graph.add_edge(parent, child)
    if not graph.nodes:
        return go.Figure()
    positions = nx.spring_layout(graph, seed=42, k=0.8, iterations=200, weight=None)
    sizes = {node: size for node, size in zip(graph.nodes(), _node_sizes([graph.nodes[n]["count"] for n in graph.nodes()]))}
    colors = {node: graph.nodes[node]["count"] for node in graph.nodes()}
    return _network_figure(graph, positions, sizes, colors, "Motif hierarchy")


def create_cooccurrence_network(
    consolidated: pd.DataFrame,
    co_occurrence: pd.DataFrame,
    threshold: int,
) -> Tuple[go.Figure, List[str]]:
    co_occurrence = co_occurrence.copy()
    co_occurrence["shared_sequences"] = pd.to_numeric(co_occurrence["shared_sequences"], errors="coerce").fillna(0).astype(int)
    counts = consolidated.set_index("core_pattern")["total_sequences"].to_dict()
    all_motifs = list(counts.keys())

    # Base graph for stable layout (all edges)
    base_graph = nx.Graph()
    for motif, count in counts.items():
        base_graph.add_node(motif, count=int(count))
    for _, row in co_occurrence.iterrows():
        a, b, weight = row["source"], row["target"], int(row["shared_sequences"])
        if base_graph.has_node(a) and base_graph.has_node(b):
            base_graph.add_edge(a, b, weight=weight)

    n_nodes = base_graph.number_of_nodes()
    if n_nodes == 0:
        return go.Figure(), []

    # Stable weighted layout using full graph
    if base_graph.number_of_edges() > 0:
        k = 1.5 / np.sqrt(max(n_nodes, 1))
        positions = nx.spring_layout(base_graph, seed=42, weight="weight", k=k, iterations=500)
    else:
        side = int(np.ceil(np.sqrt(n_nodes)))
        positions = {node: (i % side, i // side) for i, node in enumerate(base_graph.nodes())}

    # Light jitter to avoid overlap
    rng = np.random.default_rng(42)
    for node in positions:
        jx, jy = rng.normal(scale=0.05, size=2)
        x, y = positions[node]
        positions[node] = (x + float(jx), y + float(jy))

    # Prepare edges
    all_edges = []
    filtered_edges = []
    for _, row in co_occurrence.iterrows():
        a, b, weight = row["source"], row["target"], int(row["shared_sequences"])
        if a in positions and b in positions:
            all_edges.append((a, b, weight))
            if weight >= threshold:
                filtered_edges.append((a, b, weight))

    # Compute communities on filtered graph (fallback to base graph if empty)
    clusters: Dict[str, int] = {}
    graph_for_clustering = nx.Graph()
    graph_for_clustering.add_nodes_from(base_graph.nodes(data=True))
    graph_for_clustering.add_weighted_edges_from(filtered_edges)
    if graph_for_clustering.number_of_edges() == 0:
        graph_for_clustering = base_graph
    if graph_for_clustering.number_of_edges() > 0:
        try:
            comms = community.greedy_modularity_communities(graph_for_clustering, weight="weight")
            for cid, group in enumerate(comms):
                for node in group:
                    clusters[node] = cid
        except Exception:
            pass
    for node in all_motifs:
        clusters.setdefault(node, 0)

    node_sizes = {node: size for node, size in zip(all_motifs, _node_sizes([counts[n] for n in all_motifs]))}

    palette = ["#4ecdc4", "#f6c177", "#9d7cd8", "#7dd3fc", "#f28b82", "#6ee7b7", "#c084fc", "#fbbf24"]

    def cluster_color(cid: int) -> str:
        return palette[cid % len(palette)]

    cluster_to_nodes: Dict[int, List[str]] = {}
    for node, cid in clusters.items():
        cluster_to_nodes.setdefault(cid, []).append(node)

    bins = [(1, 5), (6, 20), (21, 100), (101, 10**9)]
    edge_colors = ["#b0bec5", "#8b9cfb", "#f6ad55", "#f87171"]
    edge_traces = []
    for (low, high), color in zip(bins, edge_colors):
        xs: List[float] = []
        ys: List[float] = []
        widths: List[float] = []
        for (u, v, w) in filtered_edges:
            if low <= w <= high:
                x0, y0 = positions[u]
                x1, y1 = positions[v]
                xs.extend([x0, x1, None])
                ys.extend([y0, y1, None])
                widths.append(w)
        if xs:
            label = f"{low}–{high if high < 10**9 else '+'}"
            edge_traces.append(
                go.Scatter(
                    x=xs,
                    y=ys,
                    mode="lines",
                    line=dict(width=2.0 + np.log1p(max(widths)), color=color),
                    opacity=0.7,
                    hoverinfo="none",
                    name=f"Shared: {label}",
                    showlegend=True,
                )
            )

    # Background edges (all edges, faint) to preserve structure
    if all_edges:
        xs_bg: List[float] = []
        ys_bg: List[float] = []
        for (u, v, w) in all_edges:
            x0, y0 = positions[u]
            x1, y1 = positions[v]
            xs_bg.extend([x0, x1, None])
            ys_bg.extend([y0, y1, None])
        edge_traces.insert(
            0,
            go.Scatter(
                x=xs_bg,
                y=ys_bg,
                mode="lines",
                line=dict(width=1, color="rgba(255,255,255,0.12)"),
                hoverinfo="none",
                name="All edges",
                showlegend=True,
            ),
        )

    node_traces = []
    for cid, nodes in cluster_to_nodes.items():
        node_traces.append(
            go.Scatter(
                x=[positions[n][0] for n in nodes],
                y=[positions[n][1] for n in nodes],
                mode="markers",
                text=nodes,
                customdata=nodes,
                hovertemplate="%{text}<extra></extra>",
                marker=dict(
                    size=[node_sizes.get(n, 12) for n in nodes],
                    color=cluster_color(cid),
                    line=dict(color="#0b1222", width=1),
                    opacity=0.95,
                ),
                name=f"Cluster {cid+1}",
                showlegend=True,
            )
        )

    fig = go.Figure(data=edge_traces + node_traces)
    fig.update_layout(
        template="plotly_dark",
        title=f"Co-occurrence (edges ≥ {threshold} shared sequences)",
        showlegend=True,
        margin=dict(t=40, b=20, l=20, r=20),
        xaxis=dict(showgrid=False, zeroline=False, visible=False),
        yaxis=dict(showgrid=False, zeroline=False, visible=False),
        uirevision="coocc-stable",
    )
    return fig, list(base_graph.nodes())
