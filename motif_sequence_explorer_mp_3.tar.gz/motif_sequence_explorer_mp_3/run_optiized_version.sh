PYTHONPATH=".." python -m motif_sequence_explorer_mp_3.optimized_app.app
