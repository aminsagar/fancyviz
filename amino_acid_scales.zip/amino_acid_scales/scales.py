"""Standalone helpers for loading amino acid property scales and applying them to sequences."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Tuple, Union

import numpy as np
import pandas as pd


DATA_DIR = Path(__file__).resolve().parent / "data"
"""Directory containing the extracted scale tables (TSV files)."""

# Map logical dataset names to file names and index configuration
AVAILABLE_SCALE_TABLES: Dict[str, Tuple[str, Union[int, None]]] = {
    "scales": ("scales.tsv", 0),       # Min-max normalised AAindex scales
    "scales_raw": ("scales_raw.tsv", 0),  # Raw AAindex scales
    "scales_cat": ("scales_cat.tsv", None),  # Scale category annotations
}

_AGG_FUNCTIONS = {
    "mean": np.nanmean,
    "median": np.nanmedian,
    "sum": np.nansum,
}


def _validate_table_name(name: str) -> str:
    """Ensure the requested dataset is available."""
    if name not in AVAILABLE_SCALE_TABLES:
        valid = ", ".join(sorted(AVAILABLE_SCALE_TABLES))
        raise ValueError(f"Unknown scale table '{name}'. Valid options: {valid}")
    return name


def _resolve_table_path(name: str) -> Tuple[Path, Union[int, None]]:
    """Return the file path and index configuration for a dataset."""
    filename, index_col = AVAILABLE_SCALE_TABLES[name]
    path = DATA_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Scale table '{name}' not found at {path}")
    return path, index_col


@lru_cache(maxsize=None)
def _load_table_cached(name: str) -> pd.DataFrame:
    """Load a dataset from disk with simple caching."""
    name = _validate_table_name(name)
    path, index_col = _resolve_table_path(name)
    df = pd.read_csv(path, sep="\t", index_col=index_col)
    return df


def load_scales(name: str = "scales") -> pd.DataFrame:
    """
    Load one of the extracted amino acid scale tables.

    Parameters
    ----------
    name:
        Dataset identifier. Supported values: ``'scales'``, ``'scales_raw'``, ``'scales_cat'``.

    Returns
    -------
    pandas.DataFrame
        A copy of the requested table so callers can modify it without affecting the cached version.
    """
    df = _load_table_cached(name)
    return df.copy()


def get_scale_series(scale: Union[str, pd.Series, Mapping[str, float]],
                     df_scales: pd.DataFrame | None = None) -> pd.Series:
    """
    Obtain a single amino acid scale as a pandas ``Series`` indexed by residue letter.

    Parameters
    ----------
    scale:
        Either the name of a scale column, a ``Series`` indexed by amino-acid single-letter codes,
        or a mapping providing the same information.
    df_scales:
        Optional pre-loaded ``DataFrame`` returned by :func:`load_scales`. Required when ``scale`` is a string.

    Returns
    -------
    pandas.Series
        Copy of the requested scale with uppercase residue indices.
    """
    if isinstance(scale, pd.Series):
        series = scale.copy()
    elif isinstance(scale, Mapping):
        series = pd.Series(dict(scale))
    elif isinstance(scale, str):
        if df_scales is None:
            df_scales = load_scales()
        if scale not in df_scales.columns:
            valid = ", ".join(sorted(df_scales.columns))
            raise KeyError(f"Scale '{scale}' not found. Available columns include: {valid[:200]}...")
        series = df_scales[scale].copy()
    else:
        raise TypeError("scale must be a scale name, pandas Series, or mapping of residues to values.")

    series.index = [str(residue).upper() for residue in series.index]
    return series


def _sequence_to_values(sequence: str,
                        scale_series: pd.Series,
                        missing: str) -> Tuple[np.ndarray, List[Tuple[int, str]]]:
    """Convert a sequence into an array of scale values with simple missing-residue handling."""
    seq = sequence.upper()
    lookup = scale_series.to_dict()
    values: List[float] = []
    missing_positions: List[Tuple[int, str]] = []

    for position, residue in enumerate(seq):
        if residue in lookup:
            values.append(lookup[residue])
        else:
            missing_positions.append((position, residue))
            if missing == "raise":
                raise KeyError(f"Residue '{residue}' at position {position} not found in scale.")
            if missing == "skip":
                continue
            if missing == "nan":
                values.append(np.nan)
            else:
                raise ValueError("missing must be 'raise', 'skip', or 'nan'.")

    return np.asarray(values, dtype=float), missing_positions


def calculate_sequence_scale(sequence: str,
                             scale: Union[str, pd.Series, Mapping[str, float]],
                             aggregator: str = "mean",
                             missing: str = "raise",
                             df_scales: pd.DataFrame | None = None,
                             return_missing: bool = False) -> Union[float, np.ndarray, Tuple[Any, List[Tuple[int, str]]]]:
    """
    Apply an amino acid scale to a single sequence.

    Parameters
    ----------
    sequence:
        Protein sequence provided as a string of single-letter amino acid codes.
    scale:
        Scale identifier or mapping. If a string is given, ``df_scales`` must contain the corresponding column.
    aggregator:
        How to summarise the per-residue values. Supported: ``'mean'``, ``'median'``, ``'sum'``, ``'values'``.
        ``'values'`` returns the raw NumPy array of per-residue scores.
    missing:
        Behaviour when encountering residues that are absent from the scale.
        - ``'raise'`` (default): raise a ``KeyError``.
        - ``'skip'``: ignore residues not present in the scale.
        - ``'nan'``: insert ``NaN`` for missing residues.
    df_scales:
        Optional DataFrame of scales to avoid re-loading when applying multiple scales.
    return_missing:
        If ``True``, also return a list of ``(position, residue)`` tuples for residues that were ignored or set to ``NaN``.

    Returns
    -------
    float or numpy.ndarray or tuple
        Aggregated scale value, raw per-residue values, or a tuple containing the result and missing residue information.
    """
    scale_series = get_scale_series(scale, df_scales=df_scales)
    values, missing_positions = _sequence_to_values(sequence, scale_series, missing)

    if aggregator == "values":
        result: Union[float, np.ndarray] = values
    else:
        if aggregator not in _AGG_FUNCTIONS:
            valid = ", ".join(sorted(list(_AGG_FUNCTIONS) + ["values"]))
            raise ValueError(f"Unsupported aggregator '{aggregator}'. Valid options: {valid}")
        if values.size == 0:
            raise ValueError("No scale values could be computed for the given sequence.")
        result = float(_AGG_FUNCTIONS[aggregator](values))

    if return_missing:
        return result, missing_positions
    return result


def calculate_sequence_scale_values(sequence: str,
                                    scales: Union[str, Iterable[str]],
                                    missing: str = "raise",
                                    df_scales: pd.DataFrame | None = None,
                                    include_missing: bool = False) -> Union[pd.DataFrame, Tuple[pd.DataFrame, Dict[str, List[Tuple[int, str]]]]]:
    """
    Compute residue-level scale values for a sequence across multiple scales.

    Parameters
    ----------
    sequence:
        Protein sequence provided as a string of single-letter amino acid codes.
    scales:
        A single scale identifier or an iterable of identifiers.
    missing:
        Behaviour when encountering residues that are absent from the scale. See :func:`calculate_sequence_scale`.
        Using ``'skip'`` may result in uneven array lengths and will raise an error.
    df_scales:
        Optional DataFrame of scales to avoid re-loading when applying multiple scales.
    include_missing:
        When ``True``, return a dictionary with missing-residue annotations per scale.

    Returns
    -------
    pandas.DataFrame or tuple
        DataFrame with residue positions (1-based) as index and scale names as columns.
        When ``include_missing`` is ``True`` an additional dictionary with missing-residue information is returned.
    """
    if isinstance(scales, str):
        scales = [scales]
    scales = list(scales)
    if not scales:
        raise ValueError("No scales provided.")

    value_map: Dict[str, np.ndarray] = {}
    missing_map: Dict[str, List[Tuple[int, str]]] = {}

    for scale in scales:
        series = get_scale_series(scale, df_scales=df_scales)
        values, missing_positions = _sequence_to_values(sequence, series, missing)
        value_map[scale] = values
        if include_missing and missing_positions:
            missing_map[scale] = missing_positions

    lengths = {len(vals) for vals in value_map.values()}
    if len(lengths) != 1:
        raise ValueError("Scale values have inconsistent lengths. Use 'missing' = 'raise' or 'nan' to keep alignment.")
    n_positions = lengths.pop()

    index = np.arange(1, n_positions + 1, dtype=int)
    df_values = pd.DataFrame(value_map, index=index)

    if include_missing:
        return df_values, missing_map
    return df_values


def calculate_sequences_scales(sequences: Union[Mapping[Any, str], Iterable[str]],
                               scale: Union[str, pd.Series, Mapping[str, float]],
                               aggregator: str = "mean",
                               missing: str = "raise",
                               df_scales: pd.DataFrame | None = None,
                               include_missing: bool = False) -> Union[pd.Series, Tuple[pd.Series, Dict[Any, List[Tuple[int, str]]]]]:
    """
    Apply a scale to multiple sequences and return the aggregated values.

    Parameters
    ----------
    sequences:
        Either a mapping of identifiers to sequences or an iterable of sequences. For iterables, the resulting Series
        is indexed by the enumeration order (0, 1, 2, ...).
    scale:
        Scale identifier or mapping. When a string is given, ``df_scales`` must contain the corresponding column.
    aggregator:
        Aggregator passed to :func:`calculate_sequence_scale`. ``'values'`` is not supported for batch processing.
    missing:
        Behaviour for residues absent from the scale (``'raise'``, ``'skip'``, ``'nan'``).
    df_scales:
        Optional pre-loaded DataFrame.
    include_missing:
        If ``True``, return a tuple containing the results and a dictionary of missing-residue annotations per sequence.

    Returns
    -------
    pandas.Series or tuple
        Series of aggregated scale values, optionally paired with missing-residue information.
    """
    if aggregator == "values":
        raise ValueError("Aggregator 'values' is not supported for multiple sequences. Use calculate_sequence_scale instead.")

    scale_series = get_scale_series(scale, df_scales=df_scales)

    if isinstance(sequences, Mapping):
        items = sequences.items()
    else:
        items = enumerate(sequences)

    results = []
    missing_info: Dict[Any, List[Tuple[int, str]]] = {}

    for key, sequence in items:
        value, missing_positions = calculate_sequence_scale(
            sequence,
            scale_series,
            aggregator=aggregator,
            missing=missing,
            df_scales=None,
            return_missing=True,
        )
        results.append((key, value))
        if missing_positions:
            missing_info[key] = missing_positions

    series = pd.Series(dict(results))
    if include_missing:
        return series, missing_info
    return series
