from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio
import plotly.express as px

from motif_sequence_explorer_mp_3.optimized_app_cluster.data_pipeline import prepare_dataset


DATA_PATH = Path("../sequences_with_motifs_position_independent_p65_consolidated.csv").resolve()
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def multi_component_layout(graph: nx.Graph, weight: str = "weight", seed: int = 42) -> Dict[str, Tuple[float, float]]:
    """Lay out largest component with weighted spring; place others on a grid to avoid rings."""
    positions: Dict[str, Tuple[float, float]] = {}
    components = sorted(nx.connected_components(graph), key=len, reverse=True)
    if not components:
        return positions

    largest = components[0]
    sub = graph.subgraph(largest)
    k = 1.5 / math.sqrt(max(sub.number_of_nodes(), 1))
    positions.update(nx.spring_layout(sub, seed=seed, weight=weight, k=k, iterations=600))

    # Grid-place remaining components
    others = components[1:]
    if not others:
        return positions

    grid_cols = int(math.ceil(math.sqrt(len(others))))
    cell = 8.0
    for idx, comp in enumerate(others):
        cx = (idx % grid_cols) * cell
        cy = (idx // grid_cols) * cell
        comp_sub = graph.subgraph(comp)
        comp_pos = nx.circular_layout(comp_sub, scale=2.0, center=(cx, cy))
        positions.update(comp_pos)
    return positions


def build_fig(graph: nx.Graph, positions: Dict[str, Tuple[float, float]], threshold: int) -> go.Figure:
    # Background edges (all)
    xs_bg: List[float] = []
    ys_bg: List[float] = []
    for u, v in graph.edges():
        x0, y0 = positions[u]
        x1, y1 = positions[v]
        xs_bg.extend([x0, x1, None])
        ys_bg.extend([y0, y1, None])

    background_trace = go.Scatter(
        x=xs_bg,
        y=ys_bg,
        mode="lines",
        line=dict(width=1, color="rgba(255,255,255,0.12)"),
        hoverinfo="none",
        name="All edges",
        showlegend=True,
    )

    # Foreground edges (thresholded)
    bins = [(1, 5), (6, 20), (21, 100), (101, 10**9)]
    edge_colors = ["#b0bec5", "#8b9cfb", "#f6ad55", "#f87171"]
    edge_traces = []
    for (low, high), color in zip(bins, edge_colors):
        xs: List[float] = []
        ys: List[float] = []
        widths: List[float] = []
        for u, v, data in graph.edges(data=True):
            w = data.get("weight", 1)
            if w >= threshold and low <= w <= high:
                x0, y0 = positions[u]
                x1, y1 = positions[v]
                xs.extend([x0, x1, None])
                ys.extend([y0, y1, None])
                widths.append(w)
        if xs:
            label = f"{low}–{high if high < 10**9 else '+'}"
            edge_traces.append(
                go.Scatter(
                    x=xs,
                    y=ys,
                    mode="lines",
                    line=dict(width=2.0 + np.log1p(max(widths)), color=color),
                    opacity=0.65,
                    hoverinfo="none",
                    name=f"Shared: {label}",
                    showlegend=True,
                )
            )

    # Nodes, colored by communities
    clusters: Dict[str, int] = {}
    if graph.number_of_edges() > 0:
        try:
            comms = nx.algorithms.community.greedy_modularity_communities(graph, weight="weight")
            for cid, group in enumerate(comms):
                for node in group:
                    clusters[node] = cid
        except Exception:
            pass
    for node in graph.nodes():
        clusters.setdefault(node, 0)

    palette = ["#4ecdc4", "#f6c177", "#9d7cd8", "#7dd3fc", "#f28b82", "#6ee7b7", "#c084fc", "#fbbf24"]
    def ccolor(cid: int) -> str:
        return palette[cid % len(palette)]

    node_traces = []
    cluster_to_nodes: Dict[int, List[str]] = {}
    for node, cid in clusters.items():
        cluster_to_nodes.setdefault(cid, []).append(node)

    for cid, nodes in cluster_to_nodes.items():
        node_traces.append(
            go.Scatter(
                x=[positions[n][0] for n in nodes],
                y=[positions[n][1] for n in nodes],
                mode="markers",
                text=nodes,
                customdata=nodes,
                hovertemplate="%{text}<extra></extra>",
                marker=dict(
                    size=10,
                    color=ccolor(cid),
                    line=dict(color="#0b1222", width=1),
                    opacity=0.95,
                ),
                name=f"Cluster {cid+1}",
                showlegend=True,
            )
        )

    fig = go.Figure(data=[background_trace] + edge_traces + node_traces)
    fig.update_layout(
        template="plotly_dark",
        title=f"Co-occurrence layout (edges ≥ {threshold})",
        showlegend=True,
        margin=dict(t=40, b=20, l=20, r=20),
        xaxis=dict(showgrid=False, zeroline=False, visible=False),
        yaxis=dict(showgrid=False, zeroline=False, visible=False),
    )
    return fig


def save_matplotlib(graph: nx.Graph, positions: Dict[str, Tuple[float, float]], threshold: int, outfile: Path):
    """Save a quick static PNG using matplotlib for fast inspection."""
    plt.figure(figsize=(12, 8))
    # Edges above threshold
    edges = [(u, v, d.get("weight", 1)) for u, v, d in graph.edges(data=True) if d.get("weight", 0) >= threshold]
    widths = [1.5 + math.log1p(w) for _, _, w in edges]
    nx.draw_networkx_edges(graph, pos=positions, edgelist=[(u, v) for u, v, _ in edges], width=widths, edge_color="#999999", alpha=0.5)
    # Nodes
    nx.draw_networkx_nodes(graph, pos=positions, node_size=20, node_color="#4ecdc4", alpha=0.9)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(outfile, dpi=200)
    plt.close()


def save_component_view(graph: nx.Graph, threshold: int, outfile: Path):
    # Build subgraph with edges >= threshold
    sub_edges = [(u, v, d) for u, v, d in graph.edges(data=True) if d.get("weight", 0) >= threshold]
    sub = nx.Graph()
    sub.add_nodes_from(graph.nodes(data=True))
    sub.add_edges_from(sub_edges)

    # Largest connected component only
    comps = sorted(nx.connected_components(sub), key=len, reverse=True)
    if not comps or len(comps[0]) == 0:
        return
    largest_nodes = comps[0]
    sub = sub.subgraph(largest_nodes).copy()

    if sub.number_of_edges() == 0:
        return

    k = 1.5 / math.sqrt(max(sub.number_of_nodes(), 1))
    pos = nx.spring_layout(sub, seed=42, weight="weight", k=k, iterations=500)

    plt.figure(figsize=(10, 8))
    widths = [1.5 + math.log1p(d.get("weight", 1)) for _, _, d in sub.edges(data=True)]
    nx.draw_networkx_edges(sub, pos=pos, width=widths, edge_color="#999999", alpha=0.6)
    nx.draw_networkx_nodes(sub, pos=pos, node_size=30, node_color="#4ecdc4", alpha=0.9)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(outfile, dpi=200)
    plt.close()


def save_connected_only_view(graph: nx.Graph, outfile: Path):
    """Render all connected motifs (no isolates) with per-component layout, no threshold."""
    sub = graph.copy()
    isolates = list(nx.isolates(sub))
    sub.remove_nodes_from(isolates)
    if sub.number_of_nodes() == 0:
        return

    pos = multi_component_layout(sub, weight="weight", seed=42)

    # Use a larger palette for components
    comps = sorted(nx.connected_components(sub), key=len, reverse=True)
    palette = px.colors.qualitative.Bold + px.colors.qualitative.Pastel + px.colors.qualitative.Set2
    comp_colors = {}
    # Convert plotly colors to hex for matplotlib
    def to_hex(c: str) -> str:
        if c.startswith("rgb"):
            nums = c.replace("rgb(", "").replace(")", "").split(",")
            r, g, b = [int(n) for n in nums]
            return "#%02x%02x%02x" % (r, g, b)
        return c

    hex_palette = [to_hex(c) for c in palette]
    for idx, comp in enumerate(comps):
        color = hex_palette[idx % len(hex_palette)]
        for node in comp:
            comp_colors[node] = color

    plt.figure(figsize=(12, 10))
    widths = [1.0 + math.log1p(d.get("weight", 1)) for _, _, d in sub.edges(data=True)]
    nx.draw_networkx_edges(sub, pos=pos, width=widths, edge_color="#9ca3af", alpha=0.5)
    nx.draw_networkx_nodes(
        sub,
        pos=pos,
        node_size=32,
        node_color=[comp_colors.get(n, "#4ecdc4") for n in sub.nodes()],
        alpha=0.95,
        edgecolors="#0b1222",
        linewidths=0.6,
    )
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(outfile, dpi=200)
    plt.close()


def main():
    dataset, _ = prepare_dataset(DATA_PATH)
    consolidated = dataset.consolidated_table
    co = pd.DataFrame(dataset.co_occurrence)

    # Build graph with all edges
    counts = consolidated.set_index("core_pattern")["total_sequences"].to_dict()
    graph = nx.Graph()
    for motif, count in counts.items():
        graph.add_node(motif, count=int(count))
    for _, row in co.iterrows():
        a, b, weight = row["source"], row["target"], int(row["shared_sequences"])
        if graph.has_node(a) and graph.has_node(b):
            graph.add_edge(a, b, weight=weight)

    comps = list(nx.connected_components(graph))
    comp_sizes = sorted([len(c) for c in comps], reverse=True)
    print(f"Nodes: {graph.number_of_nodes()}, edges: {graph.number_of_edges()}, components: {len(comps)}, largest comps: {comp_sizes[:5]}")

    positions = multi_component_layout(graph, weight="weight", seed=42)

    thresholds = [1, 3, 5, 10, 20, 50, 100]
    for th in thresholds:
        fig = build_fig(graph, positions, th)
        html_path = OUTPUT_DIR / f"coocc_threshold_{th}.html"
        fig.write_html(str(html_path))
        try:
            img_path = OUTPUT_DIR / f"coocc_threshold_{th}.png"
            save_matplotlib(graph, positions, th, img_path)
        except Exception:
            # Skip if kaleido is not installed
            pass
        print(f"Saved {html_path.name}")

    # Largest connected component views (matplotlib, edges >= threshold)
    for th in (1, 3, 5, 10, 20, 50):
        comp_out = OUTPUT_DIR / f"coocc_component_threshold_{th}.png"
        save_component_view(graph, th, comp_out)
        print(f"Saved {comp_out.name}")

    conn_out = OUTPUT_DIR / "coocc_connected_all.png"
    save_connected_only_view(graph, conn_out)
    print(f"Saved {conn_out.name}")


if __name__ == "__main__":
    main()
