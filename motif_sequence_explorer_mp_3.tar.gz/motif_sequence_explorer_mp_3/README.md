# Sequence Motif Explorer - Multi-Page App

A multi-page Dash application for exploring sequence motif datasets with co-occurrence analysis and physicochemical property visualization.

## Features

### Overview Page (/)
- Upload CSV files or use sample dataset
- View dataset summary statistics
- Consolidated motifs table
- Multiple visualizations: Dashboard, Sunburst, Treemap, Scatter plots
- Interactive hierarchy network

### Analysis Page (/analysis)
- **Side-by-side layout for full-screen exploration:**
  - Left: Co-occurrence network with adjustable threshold
  - Right: Physicochemical scatter plots with shortlist functionality
- Click on co-occurrence network nodes to explore sequences
- Interactively select and shortlist sequences
- Download shortlist as CSV

## Installation

### Requirements
- Python 3.9 or higher
- pip

### Setup

1. Extract the zip file to your desired location

2. Open a terminal/command prompt and navigate to the extracted directory:
   ```bash
   cd path/to/motif_sequence_explorer_package
   ```

3. Create a virtual environment (recommended):
   ```bash
   # On Linux/Mac:
   python3 -m venv venv
   source venv/bin/activate

   # On Windows:
   python -m venv venv
   venv\Scripts\activate
   ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running the App

### Development Mode (with hot reloading):
```bash
python -m motif_sequence_explorer_mp_1.app
```

### Production Mode (no debug warnings):
```bash
# On Linux/Mac:
DASH_DEBUG=false python -m motif_sequence_explorer_mp_1.app

# On Windows:
set DASH_DEBUG=false
python -m motif_sequence_explorer_mp_1.app
```

The app will start at: **http://127.0.0.1:8050**

Open your web browser and navigate to this address.

## Usage

1. **Load Data**:
   - Click "Use Sample Dataset" for a demo
   - Or upload your own CSV file (must have 'Sequence' and 'Motifs' columns)

2. **Explore Overview**:
   - View summary statistics and visualizations on the main page

3. **Navigate to Analysis**:
   - Click "Analysis" link at the top
   - Adjust co-occurrence threshold with the slider
   - Click nodes in the co-occurrence network
   - Physicochemical plots will update showing sequences from the selected motif

4. **Manage Shortlist**:
   - Click points or use lasso selection on the physicochemical scatter plot
   - Download your shortlist as CSV

## File Structure

```
motif_sequence_explorer_package/
├── motif_sequence_explorer_mp_1/    # Main app package
│   ├── app.py                        # Main application file
│   ├── data_pipeline.py              # Data processing
│   ├── figures.py                    # Visualization functions
│   ├── sequence_properties.py        # Physicochemical property calculations
│   ├── assets/
│   │   └── style.css                 # Custom styling
│   └── data/
│       └── sample_sequences.csv      # Sample dataset
├── motif_consolidation.py            # Motif consolidation utilities
├── amino_acid_scales/                # Amino acid property scales
├── requirements.txt                  # Python dependencies
└── README.md                         # This file
```

## Troubleshooting

### Import Errors
Make sure you're running the app from the parent directory (the one containing this README), not from inside `motif_sequence_explorer_mp_1/`.

### Port Already in Use
If port 8050 is busy, you can specify a different port:
```python
# Edit the last line of motif_sequence_explorer_mp_1/app.py
app.run(debug=debug_mode, port=8051)  # Change 8051 to any available port
```

### Module Not Found
Ensure all dependencies are installed:
```bash
pip install -r requirements.txt
```

## Data Format

CSV files should have at minimum:
- `Sequence` column: Amino acid sequences
- `Motifs` column: Comma-separated motif patterns found in each sequence

Example:
```csv
Sequence,Motifs
ACDEFGH,ABC,DEF
GHIJKLM,GHI,JKL
```

## License

This application is provided as-is for research and analysis purposes.
