from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd

from motif_sequence_explorer_mp_3.optimized_app_heatmap.data_pipeline import prepare_dataset
from motif_sequence_explorer_mp_3.optimized_app_heatmap.sequence_properties import feature_key


DATA_PATH = Path("../sequences_with_motifs_position_independent_p65_consolidated.csv")


def load_feature_df(path: Path) -> pd.DataFrame:
    dataset, _ = prepare_dataset(path)
    feature_map = dataset.sequence_features.set_index("sequence_index").to_dict(orient="index")
    feature_df = pd.DataFrame.from_dict(feature_map, orient="index")
    feature_df.index = feature_df.index.astype(int)
    return feature_df


def benchmark(feature_df: pd.DataFrame, x_key: str, y_key: str, runs: int = 5, sample_size: int = 10000):
    times_old = []
    times_new = []
    for _ in range(runs):
        t0 = time.perf_counter()
        bg = feature_df[[x_key, y_key]].dropna()
        _ = bg.sample(min(len(bg), sample_size), random_state=42)
        times_old.append(time.perf_counter() - t0)

        t1 = time.perf_counter()
        sample_df = feature_df.sample(min(len(feature_df), sample_size), random_state=42)
        _ = sample_df[[x_key, y_key]].dropna()
        times_new.append(time.perf_counter() - t1)

    return times_old, times_new


def main():
    feature_df = load_feature_df(DATA_PATH)
    x_key = feature_key("Polarity", "Polarity") if "Polarity::Polarity" in feature_df.columns else feature_df.columns[0]
    y_key = feature_key("Composition", "AA composition") if "Composition::AA composition" in feature_df.columns else feature_df.columns[1]

    old, new = benchmark(feature_df, x_key, y_key)
    print(f"Sampled background (per-call) avg: {np.mean(old):.4f}s over {len(old)} runs")
    print(f"Pre-sampled reuse avg: {np.mean(new):.4f}s over {len(new)} runs")


if __name__ == "__main__":
    main()
