from __future__ import annotations

import itertools
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, MutableMapping, Set, Tuple

import pandas as pd
import numpy as np
import time
from datetime import datetime

from .sequence_properties import SequencePropertyCalculator

TOKEN_PATTERN = re.compile(r"\[[0-9]+\]|[A-Z]")


def tokenize_motif(motif: str) -> List[str]:
    """Split motif strings into comparable tokens."""
    if not isinstance(motif, str):
        return []
    motif = motif.strip().upper()
    return TOKEN_PATTERN.findall(motif)


def normalized_motif(motif: str) -> str:
    """Return a compact token string for substring comparisons."""
    return "".join(tokenize_motif(motif))


def is_parent_of(parent: str, child: str) -> bool:
    """Heuristic parent/child relationship based on token containment."""
    if not parent or not child or parent == child:
        return False
    parent_norm = normalized_motif(parent)
    child_norm = normalized_motif(child)
    if not parent_norm or not child_norm:
        return False
    if len(parent_norm) >= len(child_norm):
        return False
    return parent_norm in child_norm


@dataclass
class MotifDataset:
    """Container for the processed dataset used by the Dash app."""

    sequences: pd.DataFrame
    exploded: pd.DataFrame
    motif_table: pd.DataFrame
    consolidated_table: pd.DataFrame
    hierarchy: Dict[str, List[str]]
    parent_map: Dict[str, str]
    motif_to_sequences: Dict[str, Set[int]]
    sequence_lookup: Dict[int, str]
    sequence_to_motifs: Dict[int, Set[str]]
    co_occurrence: pd.DataFrame
    co_occurrence_matrix: pd.DataFrame
    sequence_features: pd.DataFrame


class ProgressLogger:
    """Collect human-readable log lines for long-running tasks."""

    def __init__(self):
        self.entries: List[str] = []

    def log(self, message: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.entries.append(f"[{timestamp}] {message}")

    def extend(self, message: str):
        self.log(message)


def load_sequence_file(path: Path | str, limit: int | None = None) -> pd.DataFrame:
    """Load the raw sequence→motif CSV in its new format."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Sequence file not found: {path}")
    df = pd.read_csv(path)
    required = {"sequence_index", "sequence", "motifs"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Sequence file missing required columns: {missing}")
    if limit is not None:
        df = df.head(limit)
    motifs_series = df["motifs"].fillna("").astype(str)
    splitted = motifs_series.str.split(";")
    df["motifs_list"] = splitted.apply(lambda vals: [motif.strip() for motif in vals if motif.strip()])
    df = df[df["motifs_list"].map(bool)].reset_index(drop=True)
    return df


def explode_motifs(df: pd.DataFrame) -> pd.DataFrame:
    """Explode the motif lists so every row references a single motif."""
    exploded = df.explode("motifs_list").rename(columns={"motifs_list": "motif"})
    exploded = exploded.dropna(subset=["motif"])
    exploded["motif"] = exploded["motif"].str.strip()
    return exploded.reset_index(drop=True)


def build_sequence_maps(exploded: pd.DataFrame) -> Tuple[Dict[str, Set[int]], Dict[int, str], Dict[int, Set[str]]]:
    """Return motif→sequences, sequence→sequence string, and sequence→motifs mappings."""
    sequence_lookup = (
        exploded[["sequence_index", "sequence"]]
        .drop_duplicates("sequence_index")
        .set_index("sequence_index")["sequence"]
        .to_dict()
    )

    motif_to_sequences = (
        exploded.groupby("motif")["sequence_index"]
        .agg(lambda s: set(s.astype(int)))
        .to_dict()
    )

    sequence_to_motifs = (
        exploded.groupby("sequence_index")["motif"]
        .agg(lambda s: set(s.dropna()))
        .to_dict()
    )
    sequence_to_motifs = {int(seq): motifs for seq, motifs in sequence_to_motifs.items()}

    return motif_to_sequences, sequence_lookup, sequence_to_motifs


def build_assignments(exploded: pd.DataFrame) -> pd.DataFrame:
    """Aggregate exploded motifs into per-sequence motif lists."""
    grouped = (
        exploded.groupby("sequence_index")
        .agg({
            "sequence": "first",
            "motif": lambda vals: sorted(set(v for v in vals if isinstance(v, str) and v)),
        })
        .reset_index()
    )
    grouped.rename(columns={"motif": "motifs"}, inplace=True)
    return grouped


def build_motif_table(exploded: pd.DataFrame, motif_to_sequences: Dict[str, Set[int]]) -> pd.DataFrame:
    """Aggregate per-motif statistics."""
    motif_df = pd.DataFrame(
        {
            "core_pattern": list(motif_to_sequences.keys()),
            "sequence_indices": [sorted(seq_indices) for seq_indices in motif_to_sequences.values()],
        }
    )
    motif_df["original_count"] = motif_df["sequence_indices"].map(len)
    motif_df["total_sequences"] = motif_df["original_count"]
    return motif_df.sort_values("total_sequences", ascending=False).reset_index(drop=True)


def build_hierarchy(motif_df: pd.DataFrame) -> Tuple[Dict[str, List[str]], Dict[str, str]]:
    """Determine parent-child relationships among motifs."""
    motifs = motif_df["core_pattern"].tolist()
    hierarchy: Dict[str, List[str]] = {}
    parent_map: Dict[str, str] = {}
    for i, parent in enumerate(motifs):
        children = []
        for j, child in enumerate(motifs):
            if i == j:
                continue
            if is_parent_of(parent, child):
                children.append(child)
                current = parent_map.get(child)
                if current is None or len(parent) > len(current):
                    parent_map[child] = parent
        if children:
            hierarchy[parent] = sorted(set(children))
    return hierarchy, parent_map


def consolidate_counts(
    motif_df: pd.DataFrame,
    hierarchy: Dict[str, List[str]],
    motif_to_sequences: Dict[str, Set[int]],
) -> Tuple[pd.DataFrame, Dict[str, Set[int]]]:
    """Roll child sequence counts up to their parents."""
    consolidated = motif_df.copy()
    consolidated["child_motifs"] = ""
    consolidated["num_children"] = 0

    motif_index = {row["core_pattern"]: idx for idx, row in consolidated.iterrows()}

    def gather_descendants(motif: str, seen: Set[str] | None = None) -> List[str]:
        seen = seen or set()
        descendants: List[str] = []
        for child in hierarchy.get(motif, []):
            if child in seen:
                continue
            seen.add(child)
            descendants.append(child)
            descendants.extend(gather_descendants(child, seen))
        return descendants

    for parent, idx in motif_index.items():
        descendants = gather_descendants(parent)
        if not descendants:
            continue
        sequence_union = set(motif_to_sequences.get(parent, set()))
        for child in descendants:
            sequence_union |= motif_to_sequences.get(child, set())
        motif_to_sequences[parent] = sequence_union
        consolidated.at[idx, "total_sequences"] = len(sequence_union)
        consolidated.at[idx, "child_motifs"] = ", ".join(descendants[:10])
        consolidated.at[idx, "num_children"] = len(descendants)

    consolidated = consolidated.sort_values("total_sequences", ascending=False).reset_index(drop=True)
    return consolidated, motif_to_sequences


def build_co_occurrence(sequence_to_motifs: Dict[int, Set[str]]) -> pd.DataFrame:
    """Compute pairwise motif co-occurrence counts."""
    counter: MutableMapping[Tuple[str, str], int] = {}
    for motifs in sequence_to_motifs.values():
        motifs = sorted(motifs)
        if len(motifs) < 2:
            continue
        for a, b in itertools.combinations(motifs, 2):
            counter[(a, b)] = counter.get((a, b), 0) + 1
    if not counter:
        return pd.DataFrame(columns=["source", "target", "shared_sequences"])
    rows = [{"source": a, "target": b, "shared_sequences": count} for (a, b), count in counter.items()]
    return pd.DataFrame(rows)


def summarise_dataset(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> Dict[str, int | float | str]:
    """Return headline metrics for summary cards."""
    if consolidated.empty:
        return {
            "motifs": 0,
            "total_sequences": 0,
            "motifs_with_children": 0,
            "max_children": 0,
            "dataset": "-",
        }
    summary = {
        "motifs": int(len(consolidated)),
        "total_sequences": int(consolidated["total_sequences"].sum()),
        "motifs_with_children": int((consolidated["num_children"] > 0).sum()),
        "max_children": int(consolidated["num_children"].max()),
        "dataset": "sequence upload",
    }
    parent_counts = [len(children) for children in hierarchy.values() if isinstance(children, list)]
    summary["average_children"] = round(sum(parent_counts) / len(parent_counts), 2) if parent_counts else 0.0
    return summary


def calculate_cooccurrence(assignments: pd.DataFrame, motif_patterns: List[str], min_shared: int = 1) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Build full co-occurrence matrix and edge list with association metrics."""
    if assignments.empty or not motif_patterns:
        empty = pd.DataFrame(np.zeros((len(motif_patterns), len(motif_patterns)), dtype=int), index=motif_patterns, columns=motif_patterns)
        return empty, pd.DataFrame(columns=["source", "target", "shared_sequences"])

    exploded = assignments[["sequence_index", "motifs"]].explode("motifs").dropna()
    exploded = exploded[exploded["motifs"].isin(motif_patterns)]
    if exploded.empty:
        empty = pd.DataFrame(np.zeros((len(motif_patterns), len(motif_patterns)), dtype=int), index=motif_patterns, columns=motif_patterns)
        return empty, pd.DataFrame(columns=["source", "target", "shared_sequences"])

    presence = pd.crosstab(exploded["sequence_index"], exploded["motifs"]).astype(np.uint8)
    presence = presence.reindex(columns=motif_patterns, fill_value=0)

    matrix_values = presence.values
    counts = matrix_values.T @ matrix_values
    matrix_df = pd.DataFrame(counts, index=motif_patterns, columns=motif_patterns)

    if min_shared > 1:
        mask = np.ones_like(counts, dtype=bool)
        np.fill_diagonal(mask, False)
        counts = counts.copy()
        counts[(counts < min_shared) & mask] = 0
        matrix_df = pd.DataFrame(counts, index=motif_patterns, columns=motif_patterns)
    else:
        counts = matrix_df.values

    totals = np.diag(counts)
    n = len(motif_patterns)
    i_idx, j_idx = np.triu_indices(n, k=1)
    shared = counts[i_idx, j_idx]
    keep = shared >= min_shared
    if not keep.any():
        return matrix_df, pd.DataFrame(columns=["source", "target", "shared_sequences"])

    shared = shared[keep]
    sources = np.array(motif_patterns)[i_idx[keep]]
    targets = np.array(motif_patterns)[j_idx[keep]]
    total_i = totals[i_idx[keep]]
    total_j = totals[j_idx[keep]]
    union = total_i + total_j - shared

    jaccard = np.divide(shared, union, out=np.zeros_like(shared, dtype=float), where=union != 0)
    cond_i_j = np.divide(shared, total_j, out=np.zeros_like(shared, dtype=float), where=total_j != 0)
    cond_j_i = np.divide(shared, total_i, out=np.zeros_like(shared, dtype=float), where=total_i != 0)

    edges_df = pd.DataFrame(
        {
            "source": sources,
            "target": targets,
            "shared_sequences": shared.astype(int),
            "motif1_total": total_i.astype(int),
            "motif2_total": total_j.astype(int),
            "jaccard": jaccard.astype(float),
            "cond_1_given_2": cond_i_j.astype(float),
            "cond_2_given_1": cond_j_i.astype(float),
        }
    )

    return matrix_df, edges_df


def prepare_dataset(path: Path | str, limit: int | None = None) -> Tuple[MotifDataset, List[str]]:
    """Full pipeline from raw CSV to consolidated tables and edges."""
    logger = ProgressLogger()

    logger.log("Loading sequence file")
    sequences = load_sequence_file(path, limit=limit)

    logger.log("Exploding motifs column")
    exploded = explode_motifs(sequences)

    logger.log("Building sequence/motif maps")
    motif_to_sequences, sequence_lookup, sequence_to_motifs = build_sequence_maps(exploded)
    assignments = build_assignments(exploded)

    logger.log("Aggregating motif table")
    motif_table = build_motif_table(exploded, motif_to_sequences)

    logger.log("Computing hierarchy and parent relationships")
    hierarchy, parent_map = build_hierarchy(motif_table)

    logger.log("Consolidating descendant counts")
    consolidated, updated_map = consolidate_counts(motif_table, hierarchy, motif_to_sequences)

    logger.log("Building co-occurrence matrix")
    co_occurrence_matrix, co_occurrence_edges = calculate_cooccurrence(assignments, consolidated["core_pattern"].tolist(), min_shared=1)

    logger.log("Precomputing physicochemical features (this may take a while)")
    start = time.perf_counter()
    calculator = SequencePropertyCalculator()
    features_df = calculator.compute_features(sequence_lookup)
    duration = time.perf_counter() - start
    logger.log(f"Feature computation finished in {duration:.1f}s")

    dataset = MotifDataset(
        sequences=sequences,
        exploded=exploded,
        motif_table=motif_table,
        consolidated_table=consolidated,
        hierarchy=hierarchy,
        parent_map=parent_map,
        motif_to_sequences=updated_map,
        sequence_lookup=sequence_lookup,
        sequence_to_motifs=sequence_to_motifs,
        co_occurrence=co_occurrence_edges,
        co_occurrence_matrix=co_occurrence_matrix,
        sequence_features=features_df,
    )
    return dataset, logger.entries
