from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

import networkx as nx
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def _node_sizes(values: Iterable[int], min_size: int = 10, max_size: int = 40) -> List[float]:
    scaled = []
    for value in values:
        size = np.log1p(value) * 6
        size = max(min_size, min(max_size, size))
        scaled.append(size)
    return scaled


def create_dashboard(consolidated: pd.DataFrame) -> go.Figure:
    """Recreate a compact dashboard similar to the original app."""
    if consolidated.empty:
        fig = make_subplots(rows=1, cols=1)
        fig.add_annotation(text="No motifs available", showarrow=False)
        return fig

    df = consolidated.copy()
    df["increase_pct"] = np.where(
        df["original_count"] > 0,
        (df["total_sequences"] - df["original_count"]) / df["original_count"] * 100,
        0,
    )
    df["motif_length"] = df["core_pattern"].str.len()

    fig = make_subplots(
        rows=2,
        cols=2,
        subplot_titles=(
            "Top Motifs (Consolidated vs Original)",
            "Count Increase Distribution",
            "Children Distribution",
            "Motif Length vs Count",
        ),
        specs=[[{"type": "bar"}, {"type": "histogram"}], [{"type": "bar"}, {"type": "scatter"}]],
    )

    top = df.head(20)
    fig.add_trace(
        go.Bar(x=top["core_pattern"], y=top["total_sequences"], name="Consolidated", marker_color="#4ecdc4"),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Bar(x=top["core_pattern"], y=top["original_count"], name="Original", marker_color="#ff6b6b"),
        row=1,
        col=1,
    )

    increases = df["increase_pct"]
    increases = increases[np.isfinite(increases) & (increases > 0)]
    fig.add_trace(
        go.Histogram(x=increases, nbinsx=30, marker_color="#feca57", name="Increase %"),
        row=1,
        col=2,
    )

    children_counts = df["num_children"].value_counts().sort_index()
    fig.add_trace(
        go.Bar(x=children_counts.index, y=children_counts.values, marker_color="#845ec2", name="# children"),
        row=2,
        col=1,
    )

    fig.add_trace(
        go.Scatter(
            x=df["motif_length"],
            y=df["total_sequences"],
            mode="markers",
            text=df["core_pattern"],
            marker=dict(
                size=_node_sizes(df["num_children"].fillna(0) + 1, min_size=8, max_size=28),
                color=df["num_children"],
                colorscale="Viridis",
                showscale=True,
                colorbar=dict(title="Children", x=1.15),
            ),
            name="Motifs",
        ),
        row=2,
        col=2,
    )

    fig.update_layout(template="plotly_dark", height=800, showlegend=True)
    fig.update_xaxes(tickangle=45, row=1, col=1)
    fig.update_yaxes(type="log", row=2, col=2)
    return fig


def _build_tree_labels(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> Tuple[List[str], List[str]]:
    parents = []
    for motif in consolidated["core_pattern"]:
        parent = None
        for potential_parent, children in hierarchy.items():
            if not isinstance(children, list):
                continue
            if motif in children:
                if parent is None or len(potential_parent) > len(parent):
                    parent = potential_parent
        parents.append(parent if parent else "All Motifs")
    labels = consolidated["core_pattern"].tolist()
    return labels, parents


def create_sunburst(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> go.Figure:
    if consolidated.empty:
        return go.Figure()
    labels, parents = _build_tree_labels(consolidated, hierarchy)
    fig = go.Figure(
        go.Sunburst(
            labels=["All Motifs"] + labels,
            parents=[""] + parents,
            values=[consolidated["total_sequences"].sum()] + consolidated["original_count"].tolist(),
            marker=dict(colors=[0] + consolidated["total_sequences"].tolist(), colorscale="Viridis"),
            hovertemplate="<b>%{label}</b><br>Original: %{value}<extra></extra>",
            branchvalues="total",
        )
    )
    fig.update_layout(template="plotly_dark", height=700, margin=dict(t=10, l=10, r=10, b=10))
    return fig


def create_treemap(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> go.Figure:
    if consolidated.empty:
        return go.Figure()
    labels, parents = _build_tree_labels(consolidated, hierarchy)
    fig = go.Figure(
        go.Treemap(
            labels=["All Motifs"] + labels,
            parents=[""] + parents,
            values=[consolidated["total_sequences"].sum()] + consolidated["total_sequences"].tolist(),
            marker=dict(colors=[0] + consolidated["total_sequences"].tolist(), colorscale="Blues"),
            hovertemplate="<b>%{label}</b><br>Total: %{value}<extra></extra>",
        )
    )
    fig.update_layout(template="plotly_dark", height=700, margin=dict(t=10, l=10, r=10, b=10))
    return fig


def create_scatter(consolidated: pd.DataFrame) -> go.Figure:
    if consolidated.empty:
        return go.Figure()
    fig = go.Figure(
        go.Scatter(
            x=consolidated["original_count"].replace(0, np.nan),
            y=consolidated["total_sequences"],
            text=consolidated["core_pattern"],
            mode="markers",
            marker=dict(
                size=_node_sizes(consolidated["num_children"].fillna(0) + 1),
                color=consolidated["num_children"],
                colorscale="Turbo",
                showscale=True,
                colorbar=dict(title="Children"),
            ),
        )
    )
    fig.update_layout(
        template="plotly_dark",
        height=600,
        xaxis_title="Original count",
        yaxis_title="Consolidated count",
        xaxis_type="log",
        yaxis_type="log",
    )
    return fig


def _component_layout(graph: nx.Graph, weight: str | None = None, spacing: float = 3.5) -> Dict[str, Tuple[float, float]]:
    """Lay out each connected component separately to avoid circular artifact."""
    positions: Dict[str, Tuple[float, float]] = {}
    offset_x = 0.0
    components = list(nx.connected_components(graph))
    if not components:
        return positions
    for comp in components:
        sub = graph.subgraph(comp)
        if sub.number_of_nodes() == 1:
            node = next(iter(sub.nodes))
            positions[node] = (offset_x, 0.0)
            offset_x += spacing
            continue
        try:
            sub_pos = nx.spring_layout(sub, seed=42, weight=weight, iterations=500)
        except Exception:  # pragma: no cover - fallback if spring_layout fails
            sub_pos = nx.kamada_kawai_layout(sub, weight=weight)
        min_x = min(coord[0] for coord in sub_pos.values())
        max_x = max(coord[0] for coord in sub_pos.values())
        width = max(1.0, max_x - min_x)
        for node, (x, y) in sub_pos.items():
            positions[node] = (x - min_x + offset_x, y)
        offset_x += width + spacing
    return positions


def _network_figure(
    graph: nx.Graph,
    positions: Dict[str, Tuple[float, float]],
    node_sizes: Dict[str, float],
    node_colors: Dict[str, float],
    title: str,
) -> go.Figure:
    edge_x: List[float] = []
    edge_y: List[float] = []
    for u, v in graph.edges():
        x0, y0 = positions[u]
        x1, y1 = positions[v]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])

    edge_trace = go.Scatter(
        x=edge_x,
        y=edge_y,
        mode="lines",
        line=dict(width=1, color="rgba(200,200,200,0.5)"),
        hoverinfo="none",
    )

    node_trace = go.Scatter(
        x=[positions[node][0] for node in graph.nodes()],
        y=[positions[node][1] for node in graph.nodes()],
        mode="markers+text",
        text=list(graph.nodes()),
        textposition="bottom center",
        textfont=dict(size=11, color="#FFFFFF"),
        hovertext=[
            f"{node}<br>Count: {graph.nodes[node].get('count', 0):,}" for node in graph.nodes()
        ],
        hoverinfo="text",
        customdata=list(graph.nodes()),
        marker=dict(
            size=[node_sizes.get(node, 15) for node in graph.nodes()],
            color=[node_colors.get(node, 0) for node in graph.nodes()],
            colorscale="Viridis",
            showscale=True,
            colorbar=dict(title="Count"),
            line=dict(color="#1f2630", width=1),
        ),
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        template="plotly_dark",
        title=title,
        showlegend=False,
        margin=dict(t=40, b=20, l=20, r=20),
        xaxis=dict(showgrid=False, zeroline=False, visible=False),
        yaxis=dict(showgrid=False, zeroline=False, visible=False),
    )
    return fig


def create_hierarchy_network(consolidated: pd.DataFrame, hierarchy: Dict[str, List[str]]) -> go.Figure:
    graph = nx.DiGraph()
    for _, row in consolidated.iterrows():
        graph.add_node(row["core_pattern"], count=int(row["total_sequences"]))
    for parent, children in hierarchy.items():
        for child in children:
            if parent in graph and child in graph:
                graph.add_edge(parent, child)
    if not graph.nodes:
        return go.Figure()
    positions = nx.spring_layout(graph, seed=42, k=0.8, iterations=200, weight=None)
    sizes = {node: size for node, size in zip(graph.nodes(), _node_sizes([graph.nodes[n]["count"] for n in graph.nodes()]))}
    colors = {node: graph.nodes[node]["count"] for node in graph.nodes()}
    return _network_figure(graph, positions, sizes, colors, "Motif hierarchy")


def create_cooccurrence_network(
    consolidated: pd.DataFrame,
    co_occurrence: pd.DataFrame,
    threshold: int,
) -> Tuple[go.Figure, List[str]]:
    counts = consolidated.set_index("core_pattern")["total_sequences"].to_dict()
    graph = nx.Graph()
    for motif, count in counts.items():
        graph.add_node(motif, count=int(count))
    filtered = co_occurrence[co_occurrence["shared_sequences"] >= threshold]
    for _, row in filtered.iterrows():
        a, b, weight = row["source"], row["target"], int(row["shared_sequences"])
        if graph.has_node(a) and graph.has_node(b):
            graph.add_edge(a, b, weight=weight)
    if graph.number_of_edges() == 0:
        fig = go.Figure()
        fig.add_annotation(
            text=f"No motif pairs share ≥ {threshold} sequences.",
            showarrow=False,
            font=dict(color="#FFFFFF"),
        )
        fig.update_layout(template="plotly_dark", height=400)
        return fig, []
    graph.remove_nodes_from(list(nx.isolates(graph)))
    if not graph.nodes:
        fig = go.Figure()
        fig.add_annotation(
            text=f"No motif pairs share ≥ {threshold} sequences.",
            showarrow=False,
            font=dict(color="#FFFFFF"),
        )
        fig.update_layout(template="plotly_dark", height=400)
        return fig, []
    positions = _component_layout(graph, weight="weight")
    sizes = {
        node: size
        for node, size in zip(graph.nodes(), _node_sizes([graph.nodes[n]["count"] for n in graph.nodes()]))
    }
    colors = {node: graph.nodes[node]["count"] for node in graph.nodes()}
    fig = _network_figure(graph, positions, sizes, colors, f"Co-occurrence (≥ {threshold} shared sequences)")
    return fig, list(graph.nodes())
