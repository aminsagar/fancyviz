"""Minimal utilities for working with amino acid property scales."""

from .scales import (
    DATA_DIR,
    AVAILABLE_SCALE_TABLES,
    load_scales,
    get_scale_series,
    calculate_sequence_scale,
    calculate_sequences_scales,
    calculate_sequence_scale_values,
)

__all__ = [
    "DATA_DIR",
    "AVAILABLE_SCALE_TABLES",
    "load_scales",
    "get_scale_series",
    "calculate_sequence_scale",
    "calculate_sequences_scales",
    "calculate_sequence_scale_values",
]
